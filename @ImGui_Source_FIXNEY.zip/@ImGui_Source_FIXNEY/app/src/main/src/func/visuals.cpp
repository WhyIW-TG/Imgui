#include "visuals.hpp"
#include "../game/game.hpp"
#include "../game/offsets.hpp"
#include "../game/math.hpp"
#include "../game/player.hpp"
#include "../ui/theme/theme.hpp"
#include "../ui/cfg.hpp"
#include "../protect/oxorany.hpp"
#include "imgui.h"
#include "imgui_internal.h"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <algorithm>

// espFont объявлен в draw.h как extern — определение там же через fontMedium fallback
// Здесь удаляем дублирующий extern, используем fontMedium из theme напрямую

// ─────────────────────────────────────────────────────────────────────────────
//  INTERNAL HELPERS
// ─────────────────────────────────────────────────────────────────────────────

// helper: ImVec4 + RGB флаг → ImU32 с полной альфой
static inline ImU32 esp_col32(const ImVec4& c, bool rgb, float phase = 0.f) {
    if (rgb) return cfg::rgb::color32(255, phase);
    return IM_COL32((int)(c.x*255),(int)(c.y*255),(int)(c.z*255),(int)(c.w*255));
}

// helper: ImVec4 + RGB флаг → ImU32 с заданной альфой
static inline ImU32 esp_col32a(const ImVec4& c, bool rgb, int alpha, float phase = 0.f) {
    if (rgb) return cfg::rgb::color32(alpha, phase);
    return IM_COL32((int)(c.x*255),(int)(c.y*255),(int)(c.z*255), alpha);
}

// helper: вращение точки вокруг центра на угол a (радианы)
static inline ImVec2 rotate_around(float cx, float cy,
                                   float dx, float dy, float a)
{
    float c = cosf(a), s = sinf(a);
    return ImVec2(cx + dx * c - dy * s,
                  cy + dx * s + dy * c);
}

// ─────────────────────────────────────────────────────────────────────────────
//  DrawGradientRounded
//  Градиентный fill с округлёнными углами через ручную запись вершин.
//  C++14: никаких лямбд, никаких auto-параметров.
// ─────────────────────────────────────────────────────────────────────────────
static void draw_gradient_rounded(ImDrawList* dl,
                                  ImVec2 pMin, ImVec2 pMax,
                                  ImU32 col_top, ImU32 col_bot,
                                  float rnd)
{
    if (rnd < 0.5f) {
        dl->AddRectFilledMultiColor(pMin, pMax, col_top, col_top, col_bot, col_bot);
        return;
    }

    float w = pMax.x - pMin.x;
    float h = pMax.y - pMin.y;
    if (w < 1.f || h < 1.f) return;

    float half_min = (w < h ? w : h) * 0.5f;
    if (rnd > half_min) rnd = half_min;

    // Распаковка IM_COL32 (LE: R=bits0-7, G=8-15, B=16-23, A=24-31)
    float tr = (float)((col_top >>  0) & 0xFF);
    float tg = (float)((col_top >>  8) & 0xFF);
    float tb = (float)((col_top >> 16) & 0xFF);
    float ta = (float)((col_top >> 24) & 0xFF);
    float br = (float)((col_bot >>  0) & 0xFF);
    float bg = (float)((col_bot >>  8) & 0xFF);
    float bb = (float)((col_bot >> 16) & 0xFF);
    float ba = (float)((col_bot >> 24) & 0xFF);

    // Lerp по нормализованной Y
    #define LGCOL(yn) IM_COL32( \
        (int)(tr + (br - tr) * (yn)), \
        (int)(tg + (bg - tg) * (yn)), \
        (int)(tb + (bb - tb) * (yn)), \
        (int)(ta + (ba - ta) * (yn))  \
    )

    const int ARC_SEGS = 8;
    const int N_PERIM  = 4 * ARC_SEGS;
    const int N_VTX    = N_PERIM + 1;
    const int N_IDX    = N_PERIM * 3;

    dl->PrimReserve(N_IDX, N_VTX);

    ImVec2      uv        = dl->_Data->TexUvWhitePixel;
    ImDrawVert* vw        = dl->_VtxWritePtr;
    ImDrawIdx*  iw        = dl->_IdxWritePtr;
    ImDrawIdx   base      = (ImDrawIdx)dl->_VtxCurrentIdx;

    // вертекс 0 — центр
    float cxm = (pMin.x + pMax.x) * 0.5f;
    float cym = (pMin.y + pMax.y) * 0.5f;
    vw[0].pos = ImVec2(cxm, cym);
    vw[0].uv  = uv;
    vw[0].col = LGCOL(0.5f);

    float cx0 = pMin.x + rnd;
    float cx1 = pMax.x - rnd;
    float cy0 = pMin.y + rnd;
    float cy1 = pMax.y - rnd;

    int vi = 1;

    // TL: 180° → 270°
    for (int i = 0; i < ARC_SEGS; i++) {
        float a  = IM_PI * 1.0f + (IM_PI * 0.5f) * ((float)i / (float)ARC_SEGS);
        float vx = cx0 + cosf(a) * rnd;
        float vy = cy0 + sinf(a) * rnd;
        vw[vi].pos = ImVec2(vx, vy);
        vw[vi].uv  = uv;
        vw[vi].col = LGCOL((vy - pMin.y) / h);
        vi++;
    }
    // TR: 270° → 360°
    for (int i = 0; i < ARC_SEGS; i++) {
        float a  = IM_PI * 1.5f + (IM_PI * 0.5f) * ((float)i / (float)ARC_SEGS);
        float vx = cx1 + cosf(a) * rnd;
        float vy = cy0 + sinf(a) * rnd;
        vw[vi].pos = ImVec2(vx, vy);
        vw[vi].uv  = uv;
        vw[vi].col = LGCOL((vy - pMin.y) / h);
        vi++;
    }
    // BR: 0° → 90°
    for (int i = 0; i < ARC_SEGS; i++) {
        float a  = 0.f + (IM_PI * 0.5f) * ((float)i / (float)ARC_SEGS);
        float vx = cx1 + cosf(a) * rnd;
        float vy = cy1 + sinf(a) * rnd;
        vw[vi].pos = ImVec2(vx, vy);
        vw[vi].uv  = uv;
        vw[vi].col = LGCOL((vy - pMin.y) / h);
        vi++;
    }
    // BL: 90° → 180°
    for (int i = 0; i < ARC_SEGS; i++) {
        float a  = IM_PI * 0.5f + (IM_PI * 0.5f) * ((float)i / (float)ARC_SEGS);
        float vx = cx0 + cosf(a) * rnd;
        float vy = cy1 + sinf(a) * rnd;
        vw[vi].pos = ImVec2(vx, vy);
        vw[vi].uv  = uv;
        vw[vi].col = LGCOL((vy - pMin.y) / h);
        vi++;
    }

    // Fan triangulation
    for (int i = 0; i < N_PERIM; i++) {
        iw[i * 3 + 0] = base;
        iw[i * 3 + 1] = (ImDrawIdx)(base + 1 + i);
        iw[i * 3 + 2] = (ImDrawIdx)(base + 1 + (i + 1) % N_PERIM);
    }

    dl->_VtxWritePtr   += N_VTX;
    dl->_IdxWritePtr   += N_IDX;
    dl->_VtxCurrentIdx += (unsigned int)N_VTX;

    #undef LGCOL
}

// ─────────────────────────────────────────────────────────────────────────────
//  SKELETON HELPER
// ─────────────────────────────────────────────────────────────────────────────

static void skel_line(ImDrawList* dl, ImU32 col,
                      const ImVec2& a, const ImVec2& b)
{
    dl->AddLine(a, b, IM_COL32(0,0,0,200), 2.8f);
    dl->AddLine(a, b, col,                  1.6f);
}

// ─────────────────────────────────────────────────────────────────────────────
//  PUBLIC API
// ─────────────────────────────────────────────────────────────────────────────

void visuals::draw_text_outlined(ImDrawList* dl, ImFont* font, float size,
                                 const ImVec2& pos, ImU32 color, const char* text)
{
    if (!font || !dl || !text) return;
    int a  = (color >> IM_COL32_A_SHIFT) & 0xFF;
    int s1 = (int)(a * 0.4f);
    int s2 = (int)(a * 0.7f);
    dl->AddText(font, size, ImVec2(pos.x + 2.f, pos.y + 2.f), IM_COL32(0,0,0,s1), text);
    dl->AddText(font, size, ImVec2(pos.x + 1.f, pos.y + 1.f), IM_COL32(0,0,0,s2), text);
    dl->AddText(font, size, pos,                               color,               text);
}

// ── Full box (outline + тень) ─────────────────────────────────────────────────
void visuals::dbox_full(ImDrawList* dl, const ImRect& r, float alpha) {
    ImU32 col   = esp_col32a(cfg::esp::box_col, cfg::esp::box_rgb,
                             (int)(cfg::esp::box_col.w * alpha * 255.f), 0.f);
    ImU32 black = IM_COL32(0, 0, 0, (int)(255 * alpha));
    float rnd   = cfg::esp::box_rounding;
    dl->AddRect(r.Min, r.Max, black, rnd, 0, 2.8f);
    dl->AddRect(r.Min, r.Max, col,   rnd, 0, 1.6f);
}

// ── Corner box ───────────────────────────────────────────────────────────────
void visuals::dbox_corner(ImDrawList* dl, const ImRect& r, float alpha) {
    ImU32 col   = esp_col32a(cfg::esp::box_col, cfg::esp::box_rgb,
                             (int)(cfg::esp::box_col.w * alpha * 255.f), 0.3f);
    ImU32 black = IM_COL32(0, 0, 0, (int)(255 * alpha));
    float w  = r.Max.x - r.Min.x;
    float h  = r.Max.y - r.Min.y;
    float cl = fminf(w, h) * 0.25f;

    // TL
    dl->AddLine(ImVec2(r.Min.x,      r.Min.y),      ImVec2(r.Min.x + cl, r.Min.y),      black, 2.8f);
    dl->AddLine(ImVec2(r.Min.x,      r.Min.y),      ImVec2(r.Min.x,      r.Min.y + cl), black, 2.8f);
    dl->AddLine(ImVec2(r.Min.x,      r.Min.y),      ImVec2(r.Min.x + cl, r.Min.y),      col,   1.6f);
    dl->AddLine(ImVec2(r.Min.x,      r.Min.y),      ImVec2(r.Min.x,      r.Min.y + cl), col,   1.6f);
    // TR
    dl->AddLine(ImVec2(r.Max.x,      r.Min.y),      ImVec2(r.Max.x - cl, r.Min.y),      black, 2.8f);
    dl->AddLine(ImVec2(r.Max.x,      r.Min.y),      ImVec2(r.Max.x,      r.Min.y + cl), black, 2.8f);
    dl->AddLine(ImVec2(r.Max.x,      r.Min.y),      ImVec2(r.Max.x - cl, r.Min.y),      col,   1.6f);
    dl->AddLine(ImVec2(r.Max.x,      r.Min.y),      ImVec2(r.Max.x,      r.Min.y + cl), col,   1.6f);
    // BL
    dl->AddLine(ImVec2(r.Min.x,      r.Max.y),      ImVec2(r.Min.x + cl, r.Max.y),      black, 2.8f);
    dl->AddLine(ImVec2(r.Min.x,      r.Max.y),      ImVec2(r.Min.x,      r.Max.y - cl), black, 2.8f);
    dl->AddLine(ImVec2(r.Min.x,      r.Max.y),      ImVec2(r.Min.x + cl, r.Max.y),      col,   1.6f);
    dl->AddLine(ImVec2(r.Min.x,      r.Max.y),      ImVec2(r.Min.x,      r.Max.y - cl), col,   1.6f);
    // BR
    dl->AddLine(ImVec2(r.Max.x,      r.Max.y),      ImVec2(r.Max.x - cl, r.Max.y),      black, 2.8f);
    dl->AddLine(ImVec2(r.Max.x,      r.Max.y),      ImVec2(r.Max.x,      r.Max.y - cl), black, 2.8f);
    dl->AddLine(ImVec2(r.Max.x,      r.Max.y),      ImVec2(r.Max.x - cl, r.Max.y),      col,   1.6f);
    dl->AddLine(ImVec2(r.Max.x,      r.Max.y),      ImVec2(r.Max.x,      r.Max.y - cl), col,   1.6f);
}

// ── Fill (normal / gradient) ──────────────────────────────────────────────────
void visuals::dbox_fill(ImDrawList* dl, const ImRect& r) {
    if (!cfg::esp::box_fill) return;
    float rnd = cfg::esp::box_rounding;
    int   a   = (int)(cfg::esp::fill_alpha * 255.f);

    if (cfg::esp::fill_type == 1) {
        ImVec4 ct4, cb4;
        if (cfg::esp::fill_rgb) {
            ct4 = cfg::rgb::color4(0.0f); ct4.w = cfg::esp::fill_alpha;
            cb4 = cfg::rgb::color4(0.5f); cb4.w = cfg::esp::fill_alpha;
        } else {
            ct4 = ImVec4(cfg::esp::fill_col_top.x, cfg::esp::fill_col_top.y,
                         cfg::esp::fill_col_top.z, cfg::esp::fill_alpha);
            cb4 = ImVec4(cfg::esp::fill_col_bot.x, cfg::esp::fill_col_bot.y,
                         cfg::esp::fill_col_bot.z, cfg::esp::fill_alpha);
        }
        ImU32 cu = IM_COL32((int)(ct4.x*255),(int)(ct4.y*255),(int)(ct4.z*255),(int)(ct4.w*255));
        ImU32 cl = IM_COL32((int)(cb4.x*255),(int)(cb4.y*255),(int)(cb4.z*255),(int)(cb4.w*255));
        draw_gradient_rounded(dl, r.Min, r.Max, cu, cl, rnd);
    } else {
        ImU32 col = esp_col32a(cfg::esp::fill_col, cfg::esp::fill_rgb, a, 2.0f);
        dl->AddRectFilled(r.Min, r.Max, col, rnd);
    }
}

// ── ESP line (от низа экрана к игроку) ───────────────────────────────────────
void visuals::dline(ImDrawList* dl, const ImRect& r) {
    if (!cfg::esp::line) return;
    ImVec2 src((float)g_sw * 0.5f, (float)g_sh);
    ImVec2 dst((r.Min.x + r.Max.x) * 0.5f, r.Max.y);
    ImU32 col = esp_col32(cfg::esp::line_col, cfg::esp::line_rgb, 1.5f);
    dl->AddLine(src, dst, IM_COL32(0,0,0,150), 2.2f);
    dl->AddLine(src, dst, col,                  1.2f);
}

// ── Head circle ──────────────────────────────────────────────────────────────
void visuals::dhead_circle(ImDrawList* dl, const ImRect& r) {
    if (!cfg::esp::head_circle) return;
    float w      = r.Max.x - r.Min.x;
    float radius = w * 0.22f;
    if (radius < 2.f) radius = 2.f;
    // Над головой: центр на r.Min.y - radius (выше бокса)
    // Опускаем внутрь бокса: центр на r.Min.y + radius
    ImVec2 center((r.Min.x + r.Max.x) * 0.5f, r.Min.y + radius);
    ImU32 col = esp_col32(cfg::esp::head_circle_col, cfg::esp::head_circle_rgb, 0.f);
    dl->AddCircle(center, radius + 1.5f, IM_COL32(0,0,0,200), 20, 1.8f);
    dl->AddCircle(center, radius,        col,                   20, 1.2f);
}

// ── Distance text (справа от бокса) ──────────────────────────────────────────
void visuals::ddist(ImDrawList* dl, const ImRect& r, float dist) {
    if (!cfg::esp::distance) return;
    char buf[16];
    int dm = (int)(dist + 0.5f);
    if (dm < 0) dm = 0;
    snprintf(buf, sizeof(buf), "%dm", dm);
    ImVec2 tsz = ImGui::CalcTextSize(buf);
    float  tx  = r.Max.x + 5.f;
    float  ty  = (r.Min.y + r.Max.y) * 0.5f - tsz.y * 0.5f;
    ImU32 col = esp_col32(cfg::esp::distance_col, cfg::esp::distance_rgb, 0.f);
    dl->AddText(ImVec2(tx + 1.f, ty + 1.f), IM_COL32(0,0,0,255), buf);
    dl->AddText(ImVec2(tx,       ty),        col,                  buf);
}

// ── Nickname (над боксом) ─────────────────────────────────────────────────────
void visuals::dnick(ImDrawList* dl, const ImRect& r, const char* nick) {
    if (!cfg::esp::name || !nick || nick[0] == '\0') return;
    ImVec2 tsz = ImGui::CalcTextSize(nick);
    float  tx  = (r.Min.x + r.Max.x) * 0.5f - tsz.x * 0.5f;
    float  ty  = r.Min.y - tsz.y - 5.0f;
    ImU32 col = esp_col32(cfg::esp::name_col, cfg::esp::name_rgb, 0.6f);
    dl->AddText(ImVec2(tx + 1.f, ty + 1.f), IM_COL32(0,0,0,255), nick);
    dl->AddText(ImVec2(tx,       ty),        col,                  nick);
}

// ── HP bar (слева от бокса) ───────────────────────────────────────────────────
void visuals::dhp_bar(ImDrawList* dl, const ImRect& r, int hp) {
    if (!cfg::esp::health) return;
    float bw  = 3.0f;
    float bh  = r.Max.y - r.Min.y;
    float bx  = r.Min.x - bw - 5.0f;
    float by  = r.Min.y;
    dl->AddRectFilled(ImVec2(bx, by), ImVec2(bx + bw, by + bh), IM_COL32(0,0,0,200));
    float pct = hp / 100.0f;
    if (pct > 1.f) pct = 1.f;
    if (pct < 0.f) pct = 0.f;
    float hpH = bh * pct;
    float hpY = by + (bh - hpH);
    ImU32 col;
    if (cfg::esp::health_rgb) {
        col = esp_col32(cfg::esp::health_col, true, 1.0f);
    } else {
        col = IM_COL32(
            (int)(cfg::esp::health_col.x * 255),
            (int)(cfg::esp::health_col.y * 255),
            (int)(cfg::esp::health_col.z * 255), 255);
    }
    dl->AddRectFilled(ImVec2(bx, hpY), ImVec2(bx + bw, by + bh), col);
    dl->AddRect(ImVec2(bx, by), ImVec2(bx + bw, by + bh), IM_COL32(0,0,0,255), 0, 0, 1.0f);
}

// ── HP text (под боксом) ──────────────────────────────────────────────────────
void visuals::dhp_text(ImDrawList* dl, const ImRect& r, int hp) {
    if (!cfg::esp::health_text) return;
    char buf[16];
    snprintf(buf, sizeof(buf), "%d HP", hp);
    ImVec2 tsz = ImGui::CalcTextSize(buf);
    float  tx  = (r.Min.x + r.Max.x) * 0.5f - tsz.x * 0.5f;
    float  ty  = r.Max.y + 5.0f;
    ImU32 col;
    if (cfg::esp::hptext_rgb) {
        col = esp_col32(cfg::esp::hptext_col, true, 1.2f);
    } else {
        col = IM_COL32(
            (int)(cfg::esp::hptext_col.x * 255),
            (int)(cfg::esp::hptext_col.y * 255),
            (int)(cfg::esp::hptext_col.z * 255), 255);
    }
    dl->AddText(ImVec2(tx + 1.f, ty + 1.f), IM_COL32(0,0,0,255), buf);
    dl->AddText(ImVec2(tx,       ty),        col,                  buf);
}


// ── Crosshair (8 типов) ───────────────────────────────────────────────────────
// ── Fake Skeleton (пропорции от бокса) ───────────────────────────────────────
void visuals::dskeleton(ImDrawList* dl, const ImRect& r) {
    if (!cfg::esp::skeleton) return;

    float w   = r.Max.x - r.Min.x;
    float h   = r.Max.y - r.Min.y;
    float cx  = (r.Min.x + r.Max.x) * 0.5f;
    float top = r.Min.y;
    float bot = r.Max.y;

    ImU32 col = esp_col32(cfg::esp::skeleton_col, cfg::esp::skeleton_rgb, 0.f);

    // head circle radius = w * 0.22 — голова заканчивается на top + w*0.44
    // шея начинается ниже головы
    float hcr = w * 0.22f;  // head circle radius (совпадает с dhead_circle)

    ImVec2 neck   (cx,              top + hcr * 2.0f);
    ImVec2 chest  (cx,              top + h * 0.28f);
    ImVec2 pelvis (cx,              top + h * 0.55f);

    // Руки — не выходят за бокс, плечи на уровне груди
    ImVec2 l_shldr(cx - w * 0.38f,  top + h * 0.28f);
    ImVec2 l_elbow(cx - w * 0.44f,  top + h * 0.42f);
    ImVec2 l_hand (cx - w * 0.38f,  top + h * 0.55f);

    ImVec2 r_shldr(cx + w * 0.38f,  top + h * 0.28f);
    ImVec2 r_elbow(cx + w * 0.44f,  top + h * 0.42f);
    ImVec2 r_hand (cx + w * 0.38f,  top + h * 0.55f);

    // Ноги — узкие, расходятся от паха
    ImVec2 l_hip  (cx - w * 0.14f,  top + h * 0.55f);
    ImVec2 l_knee (cx - w * 0.16f,  top + h * 0.76f);
    ImVec2 l_foot (cx - w * 0.13f,  bot);

    ImVec2 r_hip  (cx + w * 0.14f,  top + h * 0.55f);
    ImVec2 r_knee (cx + w * 0.16f,  top + h * 0.76f);
    ImVec2 r_foot (cx + w * 0.13f,  bot);

    // ── Позвоночник ───────────────────────────────────────────
    skel_line(dl, col, neck,   chest);
    skel_line(dl, col, chest,  pelvis);

    // ── Ключицы ───────────────────────────────────────────────
    skel_line(dl, col, chest,   l_shldr);
    skel_line(dl, col, chest,   r_shldr);

    // ── Руки ─────────────────────────────────────────────────
    skel_line(dl, col, l_shldr, l_elbow);
    skel_line(dl, col, l_elbow, l_hand);
    skel_line(dl, col, r_shldr, r_elbow);
    skel_line(dl, col, r_elbow, r_hand);

    // ── Таз ──────────────────────────────────────────────────
    skel_line(dl, col, pelvis, l_hip);
    skel_line(dl, col, pelvis, r_hip);

    // ── Ноги ─────────────────────────────────────────────────
    skel_line(dl, col, l_hip,  l_knee);
    skel_line(dl, col, l_knee, l_foot);
    skel_line(dl, col, r_hip,  r_knee);
    skel_line(dl, col, r_knee, r_foot);
}

void visuals::dcrosshair(ImDrawList* fg) {
    if (!cfg::crosshair::enabled) return;

    float cx = g_sw * 0.5f;
    float cy = g_sh * 0.5f;

    float angle = cfg::crosshair::spin
        ? ((float)ImGui::GetTime() * cfg::crosshair::spin_speed)
        : 0.f;

    ImU32 col;
    if (cfg::crosshair::rgb) {
        col = cfg::rgb::color32((int)(cfg::crosshair::color.w * 255.f), 0.7f);
    } else {
        col = IM_COL32(
            (int)(cfg::crosshair::color.x * 255),
            (int)(cfg::crosshair::color.y * 255),
            (int)(cfg::crosshair::color.z * 255),
            (int)(cfg::crosshair::color.w * 255));
    }

    ImU32 outline = IM_COL32(0, 0, 0, 200);
    float s = cfg::crosshair::size;
    float t = cfg::crosshair::thick;
    float g = cfg::crosshair::gap;

    switch (cfg::crosshair::type) {

    case 0: { // Dot (+орбита при spin)
        float rad = t * 1.5f;
        if (cfg::crosshair::outline)
            fg->AddCircleFilled(ImVec2(cx, cy), rad + 1.2f, outline, 16);
        fg->AddCircleFilled(ImVec2(cx, cy), rad, col, 16);
        if (cfg::crosshair::spin) {
            float orbit = s * 0.9f;
            ImVec2 sat = rotate_around(cx, cy, orbit, 0.f, angle);
            if (cfg::crosshair::outline)
                fg->AddCircleFilled(sat, rad * 0.7f + 1.f, outline, 8);
            fg->AddCircleFilled(sat, rad * 0.7f, col, 8);
        }
        break;
    }

    case 1: { // Cross (классический)
        ImVec2 l1 = rotate_around(cx, cy, -s,  0.f, angle);
        ImVec2 l2 = rotate_around(cx, cy, -g,  0.f, angle);
        ImVec2 r1 = rotate_around(cx, cy,  g,  0.f, angle);
        ImVec2 r2 = rotate_around(cx, cy,  s,  0.f, angle);
        ImVec2 u1 = rotate_around(cx, cy, 0.f, -s,  angle);
        ImVec2 u2 = rotate_around(cx, cy, 0.f, -g,  angle);
        ImVec2 d1 = rotate_around(cx, cy, 0.f,  g,  angle);
        ImVec2 d2 = rotate_around(cx, cy, 0.f,  s,  angle);
        if (cfg::crosshair::outline) {
            fg->AddLine(l1, l2, outline, t + 2.f);
            fg->AddLine(r1, r2, outline, t + 2.f);
            fg->AddLine(u1, u2, outline, t + 2.f);
            fg->AddLine(d1, d2, outline, t + 2.f);
        }
        fg->AddLine(l1, l2, col, t);
        fg->AddLine(r1, r2, col, t);
        fg->AddLine(u1, u2, col, t);
        fg->AddLine(d1, d2, col, t);
        break;
    }

    case 2: { // Circle (+ tick при spin)
        if (cfg::crosshair::outline)
            fg->AddCircle(ImVec2(cx, cy), s + 1.5f, outline, 32, t + 2.f);
        fg->AddCircle(ImVec2(cx, cy), s, col, 32, t);
        if (cfg::crosshair::spin) {
            ImVec2 ta = rotate_around(cx, cy, 0.f, -(s + t + 3.f), angle);
            ImVec2 tb = rotate_around(cx, cy, 0.f, -(s - t - 1.f), angle);
            if (cfg::crosshair::outline)
                fg->AddLine(ta, tb, outline, t + 2.f);
            fg->AddLine(ta, tb, col, t + 0.5f);
        }
        break;
    }

    case 3: { // Horizontal + dot
        ImVec2 ba = rotate_around(cx, cy, -s, 0.f, angle);
        ImVec2 bb = rotate_around(cx, cy,  s, 0.f, angle);
        if (cfg::crosshair::outline)
            fg->AddLine(ba, bb, outline, t + 2.f);
        fg->AddLine(ba, bb, col, t);
        if (cfg::crosshair::outline)
            fg->AddCircleFilled(ImVec2(cx, cy), t * 0.6f + 1.f, outline, 8);
        fg->AddCircleFilled(ImVec2(cx, cy), t * 0.6f, col, 8);
        break;
    }

    case 4: { // V-shape
        float hs = s * 0.55f;
        ImVec2 tl  = rotate_around(cx, cy, -s,  -hs, angle);
        ImVec2 tr  = rotate_around(cx, cy,  s,  -hs, angle);
        ImVec2 bot = rotate_around(cx, cy, 0.f,  hs, angle);
        if (cfg::crosshair::outline) {
            fg->AddLine(tl, bot, outline, t + 2.f);
            fg->AddLine(tr, bot, outline, t + 2.f);
        }
        fg->AddLine(tl, bot, col, t);
        fg->AddLine(tr, bot, col, t);
        if (cfg::crosshair::outline)
            fg->AddCircleFilled(bot, t * 0.7f + 1.f, outline, 8);
        fg->AddCircleFilled(bot, t * 0.7f, col, 8);
        break;
    }

    case 5: { // Diamond
        ImVec2 tp = rotate_around(cx, cy, 0.f, -s,  angle);
        ImVec2 rp = rotate_around(cx, cy,  s,  0.f, angle);
        ImVec2 bp = rotate_around(cx, cy, 0.f,  s,  angle);
        ImVec2 lp = rotate_around(cx, cy, -s,  0.f, angle);
        if (cfg::crosshair::outline) {
            fg->AddLine(tp, rp, outline, t + 2.f);
            fg->AddLine(rp, bp, outline, t + 2.f);
            fg->AddLine(bp, lp, outline, t + 2.f);
            fg->AddLine(lp, tp, outline, t + 2.f);
        }
        fg->AddLine(tp, rp, col, t);
        fg->AddLine(rp, bp, col, t);
        fg->AddLine(bp, lp, col, t);
        fg->AddLine(lp, tp, col, t);
        break;
    }

    case 6: { // Star cross (8 лучей)
        float a45 = angle + 0.7854f;
        float ss  = s * 0.65f;
        float gg  = g * 0.65f;

        ImVec2 l1  = rotate_around(cx, cy, -s,   0.f, angle);
        ImVec2 l2  = rotate_around(cx, cy, -g,   0.f, angle);
        ImVec2 r1  = rotate_around(cx, cy,  g,   0.f, angle);
        ImVec2 r2  = rotate_around(cx, cy,  s,   0.f, angle);
        ImVec2 u1  = rotate_around(cx, cy, 0.f,  -s,  angle);
        ImVec2 u2  = rotate_around(cx, cy, 0.f,  -g,  angle);
        ImVec2 d1  = rotate_around(cx, cy, 0.f,   g,  angle);
        ImVec2 d2  = rotate_around(cx, cy, 0.f,   s,  angle);
        ImVec2 dl1 = rotate_around(cx, cy, -ss,  0.f, a45);
        ImVec2 dl2 = rotate_around(cx, cy, -gg,  0.f, a45);
        ImVec2 dr1 = rotate_around(cx, cy,  gg,  0.f, a45);
        ImVec2 dr2 = rotate_around(cx, cy,  ss,  0.f, a45);
        ImVec2 du1 = rotate_around(cx, cy, 0.f,  -ss, a45);
        ImVec2 du2 = rotate_around(cx, cy, 0.f,  -gg, a45);
        ImVec2 dd1 = rotate_around(cx, cy, 0.f,   gg, a45);
        ImVec2 dd2 = rotate_around(cx, cy, 0.f,   ss, a45);

        if (cfg::crosshair::outline) {
            fg->AddLine(l1,  l2,  outline, t + 2.f);
            fg->AddLine(r1,  r2,  outline, t + 2.f);
            fg->AddLine(u1,  u2,  outline, t + 2.f);
            fg->AddLine(d1,  d2,  outline, t + 2.f);
            fg->AddLine(dl1, dl2, outline, t + 1.5f);
            fg->AddLine(dr1, dr2, outline, t + 1.5f);
            fg->AddLine(du1, du2, outline, t + 1.5f);
            fg->AddLine(dd1, dd2, outline, t + 1.5f);
        }
        fg->AddLine(l1,  l2,  col, t);
        fg->AddLine(r1,  r2,  col, t);
        fg->AddLine(u1,  u2,  col, t);
        fg->AddLine(d1,  d2,  col, t);
        fg->AddLine(dl1, dl2, col, t * 0.8f);
        fg->AddLine(dr1, dr2, col, t * 0.8f);
        fg->AddLine(du1, du2, col, t * 0.8f);
        fg->AddLine(dd1, dd2, col, t * 0.8f);
        break;
    }

    case 7: { // T-shape
        ImVec2 tl = rotate_around(cx, cy, -s,  -g,  angle);
        ImVec2 tr = rotate_around(cx, cy,  s,  -g,  angle);
        ImVec2 tc = rotate_around(cx, cy, 0.f, -g,  angle);
        ImVec2 bc = rotate_around(cx, cy, 0.f,  s,  angle);
        if (cfg::crosshair::outline) {
            fg->AddLine(tl, tr, outline, t + 2.f);
            fg->AddLine(tc, bc, outline, t + 2.f);
        }
        fg->AddLine(tl, tr, col, t);
        fg->AddLine(tc, bc, col, t);
        if (cfg::crosshair::outline)
            fg->AddCircleFilled(ImVec2(cx, cy), t * 0.55f + 1.f, outline, 8);
        fg->AddCircleFilled(ImVec2(cx, cy), t * 0.55f, col, 8);
        break;
    }

    } // switch
}



// =============================================================================
//  НОВЫЕ ESP ФУНКЦИИ
// =============================================================================

// ── Snapline to Head ─────────────────────────────────────────────────────────
void visuals::dsnapline_head(ImDrawList* dl, const ImRect& r,
                              const ImVec2& screen_head)
{
    if (!cfg::esp::snapline_head) return;
    (void)r;
    ImVec2 src(g_sw * 0.5f, g_sh * 0.5f);
    ImU32 col = esp_col32(cfg::esp::snapline_head_col,
                          cfg::esp::snapline_head_rgb, 0.9f);
    dl->AddLine(src, screen_head, IM_COL32(0,0,0,130), 2.0f);
    dl->AddLine(src, screen_head, col,                  1.0f);
}

// ── Armor Bar (справа) ───────────────────────────────────────────────────────
void visuals::darmor_bar(ImDrawList* dl, const ImRect& r, int armor)
{
    if (!cfg::esp::armor_bar) return;
    float bw = 3.0f;
    float bh = r.Max.y - r.Min.y;
    float bx = r.Max.x + 5.0f;
    float by = r.Min.y;
    dl->AddRectFilled(ImVec2(bx, by), ImVec2(bx+bw, by+bh), IM_COL32(0,0,0,200));
    float pct = (float)armor / 100.f;
    if (pct > 1.f) pct = 1.f;
    if (pct < 0.f) pct = 0.f;
    float arH = bh * pct;
    float arY = by + (bh - arH);
    ImU32 col;
    if (cfg::esp::armor_bar_rgb)
        col = esp_col32(cfg::esp::armor_bar_col, true, 2.0f);
    else
        col = IM_COL32((int)(cfg::esp::armor_bar_col.x*255),
                       (int)(cfg::esp::armor_bar_col.y*255),
                       (int)(cfg::esp::armor_bar_col.z*255), 255);
    dl->AddRectFilled(ImVec2(bx, arY), ImVec2(bx+bw, by+bh), col);
    dl->AddRect(ImVec2(bx, by), ImVec2(bx+bw, by+bh),
                IM_COL32(0,0,0,255), 0, 0, 1.0f);
}

// ── Chams Skeleton (улучшенный скелет) ───────────────────────────────────────
// Стиль 0=Normal(outline+fill) 1=Neon(glow) 2=Rainbow
void visuals::dskel_chams(ImDrawList* dl, const ImRect& r, int hp, float dist)
{
    if (!cfg::esp::skel_chams) return;

    float w   = r.Max.x - r.Min.x;
    float h   = r.Max.y - r.Min.y;
    float cx  = (r.Min.x + r.Max.x) * 0.5f;
    float top = r.Min.y;
    float bot = r.Max.y;

    // Толщина: базовая, масштабируется по дистанции если включено
    float thick = cfg::esp::skel_thick;
    if (cfg::esp::skel_dist_scale) {
        // ближе = толще: 100м=1.6, 10м=3.0
        float t = 1.f - (dist / 100.f);
        if (t < 0.f) t = 0.f;
        if (t > 1.f) t = 1.f;
        thick = cfg::esp::skel_thick + t * 1.4f;
    }

    // Цвет по HP если включено
    float hp_t = (float)hp / 100.f;
    if (hp_t > 1.f) hp_t = 1.f;
    if (hp_t < 0.f) hp_t = 0.f;

    ImU32 col;
    float t_now = (float)ImGui::GetTime();

    if (cfg::esp::skel_style == 2) {
        // Rainbow
        col = IM_COL32(
            (int)(sinf(t_now)          * 127.f + 128.f),
            (int)(sinf(t_now + 2.094f) * 127.f + 128.f),
            (int)(sinf(t_now + 4.189f) * 127.f + 128.f),
            255);
    } else if (cfg::esp::skel_hp_color) {
        // Зелёный→Жёлтый→Красный по HP
        int r_c, g_c;
        if (hp_t > 0.5f) {
            float f = (hp_t - 0.5f) * 2.f;
            r_c = (int)((1.f - f) * 255.f);
            g_c = 255;
        } else {
            float f = hp_t * 2.f;
            r_c = 255;
            g_c = (int)(f * 255.f);
        }
        col = IM_COL32(r_c, g_c, 0, 255);
    } else {
        col = esp_col32(cfg::esp::skeleton_col, cfg::esp::skeleton_rgb, 0.f);
    }

    // Точки суставов
    float hcr = w * 0.22f;
    ImVec2 neck   (cx,             top + hcr * 2.0f);
    ImVec2 chest  (cx,             top + h * 0.28f);
    ImVec2 pelvis (cx,             top + h * 0.55f);
    ImVec2 l_shldr(cx - w*0.38f,  top + h * 0.28f);
    ImVec2 l_elbow(cx - w*0.44f,  top + h * 0.42f);
    ImVec2 l_hand (cx - w*0.38f,  top + h * 0.55f);
    ImVec2 r_shldr(cx + w*0.38f,  top + h * 0.28f);
    ImVec2 r_elbow(cx + w*0.44f,  top + h * 0.42f);
    ImVec2 r_hand (cx + w*0.38f,  top + h * 0.55f);
    ImVec2 l_hip  (cx - w*0.14f,  top + h * 0.55f);
    ImVec2 l_knee (cx - w*0.16f,  top + h * 0.76f);
    ImVec2 l_foot (cx - w*0.13f,  bot);
    ImVec2 r_hip  (cx + w*0.14f,  top + h * 0.55f);
    ImVec2 r_knee (cx + w*0.16f,  top + h * 0.76f);
    ImVec2 r_foot (cx + w*0.13f,  bot);

    // Glow-слои для Neon стиля
    if (cfg::esp::skel_style == 1) {
        ImU32 glow1 = (col & 0x00FFFFFF) | 0x18000000;
        ImU32 glow2 = (col & 0x00FFFFFF) | 0x30000000;
        float gt = thick + 4.f;
        float gt2 = thick + 2.f;
        // Glow outer
        dl->AddLine(neck,    chest,   glow1, gt);
        dl->AddLine(chest,   pelvis,  glow1, gt);
        dl->AddLine(chest,   l_shldr, glow1, gt);
        dl->AddLine(chest,   r_shldr, glow1, gt);
        dl->AddLine(l_shldr, l_elbow, glow1, gt);
        dl->AddLine(l_elbow, l_hand,  glow1, gt);
        dl->AddLine(r_shldr, r_elbow, glow1, gt);
        dl->AddLine(r_elbow, r_hand,  glow1, gt);
        dl->AddLine(pelvis,  l_hip,   glow1, gt);
        dl->AddLine(pelvis,  r_hip,   glow1, gt);
        dl->AddLine(l_hip,   l_knee,  glow1, gt);
        dl->AddLine(l_knee,  l_foot,  glow1, gt);
        dl->AddLine(r_hip,   r_knee,  glow1, gt);
        dl->AddLine(r_knee,  r_foot,  glow1, gt);
        // Glow inner
        dl->AddLine(neck,    chest,   glow2, gt2);
        dl->AddLine(chest,   pelvis,  glow2, gt2);
        dl->AddLine(chest,   l_shldr, glow2, gt2);
        dl->AddLine(chest,   r_shldr, glow2, gt2);
        dl->AddLine(l_shldr, l_elbow, glow2, gt2);
        dl->AddLine(l_elbow, l_hand,  glow2, gt2);
        dl->AddLine(r_shldr, r_elbow, glow2, gt2);
        dl->AddLine(r_elbow, r_hand,  glow2, gt2);
        dl->AddLine(pelvis,  l_hip,   glow2, gt2);
        dl->AddLine(pelvis,  r_hip,   glow2, gt2);
        dl->AddLine(l_hip,   l_knee,  glow2, gt2);
        dl->AddLine(l_knee,  l_foot,  glow2, gt2);
        dl->AddLine(r_hip,   r_knee,  glow2, gt2);
        dl->AddLine(r_knee,  r_foot,  glow2, gt2);
    }

    // Основные линии (outline + цвет)
    ImU32 black = IM_COL32(0,0,0,200);
    float ot = thick + 1.2f;

    #define CLINE(a,b) \
        dl->AddLine((a),(b), black, ot); \
        dl->AddLine((a),(b), col,   thick);

    CLINE(neck,    chest)
    CLINE(chest,   pelvis)
    CLINE(chest,   l_shldr)
    CLINE(chest,   r_shldr)
    CLINE(l_shldr, l_elbow)
    CLINE(l_elbow, l_hand)
    CLINE(r_shldr, r_elbow)
    CLINE(r_elbow, r_hand)
    CLINE(pelvis,  l_hip)
    CLINE(pelvis,  r_hip)
    CLINE(l_hip,   l_knee)
    CLINE(l_knee,  l_foot)
    CLINE(r_hip,   r_knee)
    CLINE(r_knee,  r_foot)
    #undef CLINE

    // Суставы (кружки) если включено
    if (cfg::esp::skel_joints) {
        float jr = thick * 0.9f;
        if (jr < 1.5f) jr = 1.5f;
        ImU32 jc = (col & 0x00FFFFFF) | 0xFF000000;
        dl->AddCircleFilled(neck,    jr,   jc, 8);
        dl->AddCircleFilled(chest,   jr,   jc, 8);
        dl->AddCircleFilled(pelvis,  jr,   jc, 8);
        dl->AddCircleFilled(l_shldr, jr,   jc, 8);
        dl->AddCircleFilled(l_elbow, jr*0.8f, jc, 6);
        dl->AddCircleFilled(l_hand,  jr*0.7f, jc, 6);
        dl->AddCircleFilled(r_shldr, jr,   jc, 8);
        dl->AddCircleFilled(r_elbow, jr*0.8f, jc, 6);
        dl->AddCircleFilled(r_hand,  jr*0.7f, jc, 6);
        dl->AddCircleFilled(l_knee,  jr*0.8f, jc, 6);
        dl->AddCircleFilled(r_knee,  jr*0.8f, jc, 6);
        dl->AddCircleFilled(l_foot,  jr*0.6f, jc, 6);
        dl->AddCircleFilled(r_foot,  jr*0.6f, jc, 6);
    }
}

// ── HP Color Box (рамка по цвету здоровья) ───────────────────────────────────
void visuals::dhp_color_box(ImDrawList* dl, const ImRect& r, int hp)
{
    if (!cfg::esp::hp_color_box) return;
    float t = (float)hp / 100.f;
    if (t > 1.f) t = 1.f;
    if (t < 0.f) t = 0.f;
    int rc, gc;
    if (t > 0.5f) {
        float f = (t - 0.5f) * 2.f;
        rc = (int)((1.f - f) * 255.f);
        gc = 255;
    } else {
        float f = t * 2.f;
        rc = 255;
        gc = (int)(f * 255.f);
    }
    ImU32 col   = IM_COL32(rc, gc, 0, 255);
    ImU32 black = IM_COL32(0,  0,  0, 200);
    float rnd   = cfg::esp::box_rounding;
    dl->AddRect(r.Min, r.Max, black, rnd, 0, 2.8f);
    dl->AddRect(r.Min, r.Max, col,   rnd, 0, 1.6f);
}

// ── HP Gradient Bar ───────────────────────────────────────────────────────────
void visuals::dhp_gradient_bar(ImDrawList* dl, const ImRect& r, int hp)
{
    if (!cfg::esp::hp_gradient_bar) return;
    float bw = 3.0f;
    float bh = r.Max.y - r.Min.y;
    float bx = r.Min.x - bw - 5.0f;
    float by = r.Min.y;
    dl->AddRectFilled(ImVec2(bx, by), ImVec2(bx+bw, by+bh), IM_COL32(0,0,0,200));
    float pct = (float)hp / 100.f;
    if (pct > 1.f) pct = 1.f;
    if (pct < 0.f) pct = 0.f;
    float hpH = bh * pct;
    float hpY = by + (bh - hpH);
    // Градиент: зелёный вверху → красный внизу (обратный: красный = мало HP)
    // top = зелёный (100%), bot = красный (0%)
    // Но бар заполняется снизу, значит верх полосы = текущее HP
    // Если HP высокое — полоса большая, верх = зелёный
    ImU32 c_top = IM_COL32(0,  200, 0,   255);  // зелёный
    ImU32 c_bot = IM_COL32(220, 30, 30,  255);  // красный
    dl->AddRectFilledMultiColor(
        ImVec2(bx, hpY), ImVec2(bx+bw, by+bh),
        c_top, c_top, c_bot, c_bot);
    dl->AddRect(ImVec2(bx, by), ImVec2(bx+bw, by+bh),
                IM_COL32(0,0,0,255), 0, 0, 1.0f);
}

// ── Danger Zone (пульсирующий круг если враг близко) ─────────────────────────
void visuals::ddanger_zone(ImDrawList* dl, const ImRect& r, float dist)
{
    if (!cfg::esp::danger_zone) return;
    if (dist > cfg::esp::danger_zone_dist) return;

    float t   = (float)ImGui::GetTime();
    // Пульс: 0..1..0 с частотой 3 Гц
    float pulse = sinf(t * 6.28f * 3.f) * 0.5f + 0.5f;

    float cx = (r.Min.x + r.Max.x) * 0.5f;
    float cy = (r.Min.y + r.Max.y) * 0.5f;
    float base_r = (r.Max.x - r.Min.x) * 0.6f;
    float anim_r = base_r + pulse * base_r * 0.4f;

    int alpha = (int)(pulse * 180.f + 40.f);
    ImU32 col = IM_COL32(
        (int)(cfg::esp::danger_zone_col.x * 255),
        (int)(cfg::esp::danger_zone_col.y * 255),
        (int)(cfg::esp::danger_zone_col.z * 255),
        alpha);

    dl->AddCircle(ImVec2(cx, cy), anim_r, col, 32, 1.5f);
    // Внутренний меньший круг
    dl->AddCircle(ImVec2(cx, cy), base_r * 0.5f, col, 24, 1.0f);
}

// ── Offscreen Indicator (стрелка на краю если враг за экраном) ───────────────
void visuals::doffscreen(ImDrawList* dl, const ImVec2& sp,
                          float sw, float sh,
                          const ImVec2& /*unused*/)
{
    if (!cfg::esp::offscreen) return;

    bool on_screen = (sp.x > 0.f && sp.x < sw &&
                      sp.y > 0.f && sp.y < sh);
    if (on_screen) return;

    float margin = 20.f;
    float cx = sw * 0.5f;
    float cy = sh * 0.5f;

    // Направление к врагу
    float dx = sp.x - cx;
    float dy = sp.y - cy;
    float len = sqrtf(dx*dx + dy*dy);
    if (len < 0.01f) return;
    float nx = dx / len;
    float ny = dy / len;

    // Позиция на краю экрана
    float max_x = sw * 0.5f - margin;
    float max_y = sh * 0.5f - margin;
    float scale = 1.f;
    if (fabsf(nx) > 0.f) scale = max_x / fabsf(dx);
    if (fabsf(ny) > 0.f) {
        float sy2 = max_y / fabsf(dy);
        if (sy2 < scale) scale = sy2;
    }
    float ex = cx + dx * scale;
    float ey = cy + dy * scale;
    ex = ImClamp(ex, margin, sw - margin);
    ey = ImClamp(ey, margin, sh - margin);

    // Рисуем треугольник-стрелку
    float ar = 10.f;  // размер стрелки
    float angle = atan2f(ny, nx);
    float a1 = angle;
    float a2 = angle + 2.356f;  // +135 deg
    float a3 = angle - 2.356f;  // -135 deg

    ImVec2 p1(ex + cosf(a1)*ar,      ey + sinf(a1)*ar);
    ImVec2 p2(ex + cosf(a2)*ar*0.6f, ey + sinf(a2)*ar*0.6f);
    ImVec2 p3(ex + cosf(a3)*ar*0.6f, ey + sinf(a3)*ar*0.6f);

    ImU32 col = IM_COL32(
        (int)(cfg::esp::offscreen_col.x * 255),
        (int)(cfg::esp::offscreen_col.y * 255),
        (int)(cfg::esp::offscreen_col.z * 255),
        220);
    ImU32 black = IM_COL32(0,0,0,200);

    dl->AddTriangleFilled(p1, p2, p3, (col & 0x00FFFFFF) | 0x60000000);
    dl->AddTriangle(p1, p2, p3, black, 2.5f);
    dl->AddTriangle(p1, p2, p3, col,   1.5f);
}

// ── Player Count Overlay ──────────────────────────────────────────────────────
void visuals::dplayer_count(ImDrawList* dl, int count)
{
    if (!cfg::esp::player_count) return;
    char buf[32];
    snprintf(buf, sizeof(buf), "Enemies: %d", count);
    float x = 10.f;
    float y = 10.f;
    dl->AddText(ImVec2(x+1.f, y+1.f), IM_COL32(0,0,0,255), buf);
    dl->AddText(ImVec2(x,     y),
        IM_COL32(255, 80, 80, 255), buf);
}

// ── Closest Enemy Arrow (стрелка к ближайшему) ───────────────────────────────
void visuals::dclosest_arrow(ImDrawList* dl, float sw, float sh,
                              const ImVec2& closest_screen)
{
    if (!cfg::esp::closest_arrow) return;

    float cx = sw * 0.5f;
    float cy = sh * 0.5f;
    float dx = closest_screen.x - cx;
    float dy = closest_screen.y - cy;
    float len = sqrtf(dx*dx + dy*dy);
    if (len < 1.f) return;

    float angle = atan2f(dy, dx);
    float radius = 60.f;  // расстояние от центра экрана до стрелки
    float ax = cx + cosf(angle) * radius;
    float ay = cy + sinf(angle) * radius;

    float ar = 12.f;
    float a1 = angle;
    float a2 = angle + 2.356f;
    float a3 = angle - 2.356f;

    ImVec2 p1(ax + cosf(a1)*ar,      ay + sinf(a1)*ar);
    ImVec2 p2(ax + cosf(a2)*ar*0.5f, ay + sinf(a2)*ar*0.5f);
    ImVec2 p3(ax + cosf(a3)*ar*0.5f, ay + sinf(a3)*ar*0.5f);

    float t = (float)ImGui::GetTime();
    float pulse = sinf(t * 4.f) * 0.3f + 0.7f;
    int alpha = (int)(pulse * 255.f);

    ImU32 col = IM_COL32(
        (int)(cfg::esp::closest_arrow_col.x * 255),
        (int)(cfg::esp::closest_arrow_col.y * 255),
        (int)(cfg::esp::closest_arrow_col.z * 255),
        alpha);

    dl->AddTriangleFilled(p1, p2, p3, (col & 0x00FFFFFF) | 0x50000000);
    dl->AddTriangle(p1, p2, p3, IM_COL32(0,0,0,200), 2.5f);
    dl->AddTriangle(p1, p2, p3, col,                  1.5f);
}


// =============================================================================
//  DEVICE TAG / MINI RADAR / THICK BONES
// =============================================================================


// =============================================================================
//  CHAMS BODY / HIT ZONE / FOOTPRINTS / SHADOW ESP
// =============================================================================

// ── Chams Body ───────────────────────────────────────────────────────────────
// Заливка тела полигонами по суставам скелета.
// Рисует: торс (шея→плечи→бёдра→пах), левую руку, правую руку,
//         левую ногу, правую ногу — каждый сегмент как filled quad.
void visuals::dchams_body(ImDrawList* dl, const ImRect& r)
{
    if (!cfg::esp::chams_body) return;

    float w   = r.Max.x - r.Min.x;
    float h   = r.Max.y - r.Min.y;
    float cx  = (r.Min.x + r.Max.x) * 0.5f;
    float top = r.Min.y;
    float bot = r.Max.y;

    ImU32 col;
    if (cfg::esp::chams_body_rgb) {
        float t = (float)ImGui::GetTime();
        col = IM_COL32(
            (int)(sinf(t)          * 127.f + 128.f),
            (int)(sinf(t + 2.094f) * 127.f + 128.f),
            (int)(sinf(t + 4.189f) * 127.f + 128.f),
            (int)(cfg::esp::chams_body_alpha * 255.f));
    } else {
        col = IM_COL32(
            (int)(cfg::esp::chams_body_col.x * 255),
            (int)(cfg::esp::chams_body_col.y * 255),
            (int)(cfg::esp::chams_body_col.z * 255),
            (int)(cfg::esp::chams_body_alpha * 255.f));
    }

    float hcr = w * 0.22f;

    // Ключевые точки
    ImVec2 neck   (cx,             top + hcr * 2.0f);
    ImVec2 chest  (cx,             top + h * 0.28f);
    ImVec2 pelvis (cx,             top + h * 0.55f);
    ImVec2 l_shldr(cx - w*0.38f,  top + h * 0.28f);
    ImVec2 l_elbow(cx - w*0.44f,  top + h * 0.42f);
    ImVec2 l_hand (cx - w*0.38f,  top + h * 0.55f);
    ImVec2 r_shldr(cx + w*0.38f,  top + h * 0.28f);
    ImVec2 r_elbow(cx + w*0.44f,  top + h * 0.42f);
    ImVec2 r_hand (cx + w*0.38f,  top + h * 0.55f);
    ImVec2 l_hip  (cx - w*0.14f,  top + h * 0.55f);
    ImVec2 l_knee (cx - w*0.16f,  top + h * 0.76f);
    ImVec2 l_foot (cx - w*0.13f,  bot);
    ImVec2 r_hip  (cx + w*0.14f,  top + h * 0.55f);
    ImVec2 r_knee (cx + w*0.16f,  top + h * 0.76f);
    ImVec2 r_foot (cx + w*0.13f,  bot);

    // Толщина «трубы» — половина ширины кости
    float tb = w * 0.06f;  // торс/бёдра
    float ab = w * 0.04f;  // руки
    float lb = w * 0.05f;  // ноги

    // Хелпер: рисует заполненный quad между двумя точками с заданной толщиной
    auto bone_quad = [&](const ImVec2& a, const ImVec2& b, float thick) {
        float dx = b.x - a.x;
        float dy = b.y - a.y;
        float len = sqrtf(dx*dx + dy*dy);
        if (len < 0.01f) return;
        float nx = -dy / len * thick;
        float ny =  dx / len * thick;
        ImVec2 p[4] = {
            ImVec2(a.x+nx, a.y+ny),
            ImVec2(a.x-nx, a.y-ny),
            ImVec2(b.x-nx, b.y-ny),
            ImVec2(b.x+nx, b.y+ny)
        };
        dl->AddConvexPolyFilled(p, 4, col);
    };

    // Outline col (чуть темнее/непрозрачнее)
    ImU32 out_col = (col & 0x00FFFFFF) |
        (ImMin((int)((cfg::esp::chams_body_alpha + 0.25f) * 255.f), 255) << 24);

    auto bone_outline = [&](const ImVec2& a, const ImVec2& b, float thick) {
        float dx = b.x - a.x;
        float dy = b.y - a.y;
        float len = sqrtf(dx*dx + dy*dy);
        if (len < 0.01f) return;
        float nx = -dy / len * thick;
        float ny =  dx / len * thick;
        ImVec2 p[4] = {
            ImVec2(a.x+nx, a.y+ny),
            ImVec2(a.x-nx, a.y-ny),
            ImVec2(b.x-nx, b.y-ny),
            ImVec2(b.x+nx, b.y+ny)
        };
        dl->AddPolyline(p, 4, out_col, true, 1.0f);
    };

    // ── Торс ──────────────────────────────────────────────────
    bone_quad(neck,   chest,  tb);    bone_outline(neck,   chest,  tb);
    bone_quad(chest,  pelvis, tb);    bone_outline(chest,  pelvis, tb);

    // ── Ключицы ───────────────────────────────────────────────
    bone_quad(chest, l_shldr, ab);    bone_outline(chest, l_shldr, ab);
    bone_quad(chest, r_shldr, ab);    bone_outline(chest, r_shldr, ab);

    // ── Руки ─────────────────────────────────────────────────
    bone_quad(l_shldr, l_elbow, ab);  bone_outline(l_shldr, l_elbow, ab);
    bone_quad(l_elbow, l_hand,  ab);  bone_outline(l_elbow, l_hand,  ab);
    bone_quad(r_shldr, r_elbow, ab);  bone_outline(r_shldr, r_elbow, ab);
    bone_quad(r_elbow, r_hand,  ab);  bone_outline(r_elbow, r_hand,  ab);

    // ── Таз ──────────────────────────────────────────────────
    bone_quad(pelvis, l_hip, lb);     bone_outline(pelvis, l_hip, lb);
    bone_quad(pelvis, r_hip, lb);     bone_outline(pelvis, r_hip, lb);

    // ── Ноги ─────────────────────────────────────────────────
    bone_quad(l_hip,  l_knee, lb);    bone_outline(l_hip,  l_knee, lb);
    bone_quad(l_knee, l_foot, lb);    bone_outline(l_knee, l_foot, lb);
    bone_quad(r_hip,  r_knee, lb);    bone_outline(r_hip,  r_knee, lb);
    bone_quad(r_knee, r_foot, lb);    bone_outline(r_knee, r_foot, lb);

    // Суставы
    ImU32 jcol = (col & 0x00FFFFFF) | 0xCC000000;
    float jr = tb * 0.9f;
    dl->AddCircleFilled(neck,    jr,        jcol, 8);
    dl->AddCircleFilled(chest,   jr,        jcol, 8);
    dl->AddCircleFilled(pelvis,  jr,        jcol, 8);
    dl->AddCircleFilled(l_shldr, jr*0.85f, jcol, 7);
    dl->AddCircleFilled(r_shldr, jr*0.85f, jcol, 7);
    dl->AddCircleFilled(l_elbow, ab*0.85f, jcol, 6);
    dl->AddCircleFilled(r_elbow, ab*0.85f, jcol, 6);
    dl->AddCircleFilled(l_hand,  ab*0.7f,  jcol, 6);
    dl->AddCircleFilled(r_hand,  ab*0.7f,  jcol, 6);
    dl->AddCircleFilled(l_hip,   lb*0.8f,  jcol, 7);
    dl->AddCircleFilled(r_hip,   lb*0.8f,  jcol, 7);
    dl->AddCircleFilled(l_knee,  lb*0.75f, jcol, 6);
    dl->AddCircleFilled(r_knee,  lb*0.75f, jcol, 6);
    dl->AddCircleFilled(l_foot,  lb*0.55f, jcol, 6);
    dl->AddCircleFilled(r_foot,  lb*0.55f, jcol, 6);
}

// ── Hit Zone ─────────────────────────────────────────────────────────────────
// Подсветка зон поражения: голова (круг) + торс (прямоугольник) + ноги
void visuals::dhit_zone(ImDrawList* dl, const ImRect& r)
{
    if (!cfg::esp::hit_zone) return;

    float w   = r.Max.x - r.Min.x;
    float h   = r.Max.y - r.Min.y;
    float cx  = (r.Min.x + r.Max.x) * 0.5f;
    float top = r.Min.y;

    int a = (int)(cfg::esp::hit_zone_alpha * 255.f);

    ImU32 head_col = IM_COL32(
        (int)(cfg::esp::hit_head_col.x * 255),
        (int)(cfg::esp::hit_head_col.y * 255),
        (int)(cfg::esp::hit_head_col.z * 255), a);
    ImU32 body_col = IM_COL32(
        (int)(cfg::esp::hit_body_col.x * 255),
        (int)(cfg::esp::hit_body_col.y * 255),
        (int)(cfg::esp::hit_body_col.z * 255), a);
    ImU32 leg_col  = IM_COL32(80, 180, 255, a);

    float hcr = w * 0.22f;

    // Голова — круг
    dl->AddCircleFilled(ImVec2(cx, top + hcr), hcr, head_col, 24);
    dl->AddCircle      (ImVec2(cx, top + hcr), hcr,
        (head_col & 0x00FFFFFF) | 0xAA000000, 24, 1.2f);

    // Торс — прямоугольник (шея → пах)
    float t_top = top + hcr * 2.f;
    float t_bot = top + h * 0.55f;
    float t_hw  = w * 0.36f;
    dl->AddRectFilled(
        ImVec2(cx - t_hw, t_top), ImVec2(cx + t_hw, t_bot),
        body_col, 2.f);
    dl->AddRect(
        ImVec2(cx - t_hw, t_top), ImVec2(cx + t_hw, t_bot),
        (body_col & 0x00FFFFFF) | 0xAA000000, 2.f, 0, 1.2f);

    // Ноги — два узких прямоугольника
    float l_top = top + h * 0.55f;
    float l_bot = r.Max.y;
    float lhw   = w * 0.14f;
    dl->AddRectFilled(
        ImVec2(cx - lhw*1.8f, l_top), ImVec2(cx - lhw*0.1f, l_bot),
        leg_col, 2.f);
    dl->AddRectFilled(
        ImVec2(cx + lhw*0.1f, l_top), ImVec2(cx + lhw*1.8f, l_bot),
        leg_col, 2.f);
}

// ── Shadow ESP ───────────────────────────────────────────────────────────────
void visuals::dshadow_esp(ImDrawList* dl, const ImRect& r)
{
    if (!cfg::esp::shadow_esp) return;
    float off = cfg::esp::shadow_offset;
    int   a   = (int)(cfg::esp::shadow_alpha * 255.f);
    ImU32 scol = IM_COL32(0, 0, 0, a);
    float rnd  = cfg::esp::box_rounding;
    // 3 слоя тени с нарастанием
    dl->AddRect(
        ImVec2(r.Min.x+off*3, r.Min.y+off*3),
        ImVec2(r.Max.x+off*3, r.Max.y+off*3),
        (scol & 0x00FFFFFF) | (ImMin(a/3,255) << 24), rnd, 0, 2.5f);
    dl->AddRect(
        ImVec2(r.Min.x+off*2, r.Min.y+off*2),
        ImVec2(r.Max.x+off*2, r.Max.y+off*2),
        (scol & 0x00FFFFFF) | (ImMin(a*2/3,255) << 24), rnd, 0, 1.8f);
    dl->AddRect(
        ImVec2(r.Min.x+off,   r.Min.y+off),
        ImVec2(r.Max.x+off,   r.Max.y+off),
        scol, rnd, 0, 1.2f);
}

// ── Footprints ───────────────────────────────────────────────────────────────
// Буфер следов: до 32 игроков × 24 следа.
// Каждый след хранит экранную позицию + время создания.
// Fade по alpha: свежий = полный, старый = прозрачный.

struct Footprint {
    ImVec2 pos;
    float  time;
    bool   used;
};

static const int MAX_FP_PLAYERS = 32;
static const int MAX_FP_PER     = 24;

struct FootprintTrack {
    uint64_t  addr;
    Footprint pts[MAX_FP_PER];
    int       head;   // следующая позиция записи (кольцевой буфер)
    bool      active;
};

static FootprintTrack g_fp_tracks[MAX_FP_PLAYERS];
static bool           g_fp_init = false;

static void fp_init() {
    if (g_fp_init) return;
    for (int i = 0; i < MAX_FP_PLAYERS; i++) {
        g_fp_tracks[i].active = false;
        g_fp_tracks[i].addr   = 0;
        g_fp_tracks[i].head   = 0;
        for (int j = 0; j < MAX_FP_PER; j++)
            g_fp_tracks[i].pts[j].used = false;
    }
    g_fp_init = true;
}

void visuals::footprint_push(uint64_t player_addr, const ImVec2& sf)
{
    if (!cfg::esp::footprints) return;
    fp_init();

    // Найти или создать трек для этого игрока
    FootprintTrack* track = nullptr;
    for (int i = 0; i < MAX_FP_PLAYERS; i++) {
        if (g_fp_tracks[i].active && g_fp_tracks[i].addr == player_addr) {
            track = &g_fp_tracks[i];
            break;
        }
    }
    if (!track) {
        for (int i = 0; i < MAX_FP_PLAYERS; i++) {
            if (!g_fp_tracks[i].active) {
                g_fp_tracks[i].active = true;
                g_fp_tracks[i].addr   = player_addr;
                g_fp_tracks[i].head   = 0;
                for (int j = 0; j < MAX_FP_PER; j++)
                    g_fp_tracks[i].pts[j].used = false;
                track = &g_fp_tracks[i];
                break;
            }
        }
    }
    if (!track) return;

    float now = (float)ImGui::GetTime();

    // Не добавляем след если игрок почти не двигался
    int prev = (track->head - 1 + MAX_FP_PER) % MAX_FP_PER;
    if (track->pts[prev].used) {
        float dx = sf.x - track->pts[prev].pos.x;
        float dy = sf.y - track->pts[prev].pos.y;
        if (dx*dx + dy*dy < 25.f) return;   // < 5px — не пишем
    }

    track->pts[track->head].pos  = sf;
    track->pts[track->head].time = now;
    track->pts[track->head].used = true;
    track->head = (track->head + 1) % MAX_FP_PER;
}

void visuals::dfootprints(ImDrawList* dl)
{
    if (!cfg::esp::footprints) return;
    fp_init();

    float now  = (float)ImGui::GetTime();
    float life = cfg::esp::footprints_life;
    float sz   = cfg::esp::footprints_size;

    ImU32 base_col = IM_COL32(
        (int)(cfg::esp::footprints_col.x * 255),
        (int)(cfg::esp::footprints_col.y * 255),
        (int)(cfg::esp::footprints_col.z * 255), 255);

    for (int i = 0; i < MAX_FP_PLAYERS; i++) {
        if (!g_fp_tracks[i].active) continue;

        for (int j = 0; j < MAX_FP_PER; j++) {
            Footprint& fp = g_fp_tracks[i].pts[j];
            if (!fp.used) continue;

            float age = now - fp.time;
            if (age > life) {
                fp.used = false;
                continue;
            }

            // Alpha fade: 1.0 → 0.0 за время life
            float t     = 1.f - (age / life);
            int   alpha = (int)(t * 220.f);
            float fsz   = sz * (0.5f + t * 0.5f);  // тоже уменьшается

            ImU32 col = (base_col & 0x00FFFFFF) | (alpha << 24);

            // Рисуем след: крестик из двух линий (как отпечаток ноги)
            dl->AddCircleFilled(fp.pos, fsz,        col, 8);
            dl->AddCircle      (fp.pos, fsz + 1.f,
                IM_COL32(0,0,0,(int)(t*120.f)), 8, 1.0f);
        }

        // Очистка неактивных треков (все следы истекли)
        bool any_alive = false;
        for (int j = 0; j < MAX_FP_PER; j++)
            if (g_fp_tracks[i].pts[j].used) { any_alive = true; break; }
        if (!any_alive) g_fp_tracks[i].active = false;
    }
}

// ── Device Tag ───────────────────────────────────────────────────────────────
// Рандомная иконка [iOS] или [APK] привязана к адресу Player (стабильна пока
// объект в памяти, не меняется между кадрами для одного игрока).
void visuals::ddevice_tag(ImDrawList* dl, const ImRect& r,
                           uint64_t player_addr)
{
    if (!cfg::esp::device_tag) return;

    // Детерминированный "рандом" по адресу — не меняется между кадрами
    bool is_ios = ((player_addr >> 4) & 1) == 0;
    const char* tag  = is_ios ? "[iOS]" : "[APK]";
    ImVec4      col4 = is_ios
        ? ImVec4(0.85f, 0.85f, 0.85f, 1.f)   // iOS  — серебристый
        : ImVec4(0.4f,  0.85f, 0.4f,  1.f);  // APK  — зелёный

    ImU32 col   = IM_COL32((int)(col4.x*255),(int)(col4.y*255),
                            (int)(col4.z*255), 255);
    ImU32 black = IM_COL32(0,0,0,200);

    ImFont* font = ImGui::GetFont();
    float   fs   = ImGui::GetFontSize() * 0.75f;

    // Позиция: справа от ника, выше бокса
    float tx = r.Max.x + 5.f;
    float ty = r.Min.y - fs - 2.f;

    dl->AddText(font, fs, ImVec2(tx+1.f, ty+1.f), black, tag);
    dl->AddText(font, fs, ImVec2(tx,     ty),      col,   tag);
}

// ── Thick Bones Skeleton ──────────────────────────────────────────────────────
// Скелет с разной толщиной костей: позвоночник толще, руки тоньше ног
void visuals::dthick_bones(ImDrawList* dl, const ImRect& r)
{
    if (!cfg::esp::thick_bones) return;

    float w   = r.Max.x - r.Min.x;
    float h   = r.Max.y - r.Min.y;
    float cx  = (r.Min.x + r.Max.x) * 0.5f;
    float top = r.Min.y;
    float bot = r.Max.y;

    ImU32 col   = esp_col32(cfg::esp::skeleton_col, cfg::esp::skeleton_rgb, 0.f);
    ImU32 black = IM_COL32(0,0,0,180);

    float sp = cfg::esp::thick_spine;  // позвоночник
    float ar = cfg::esp::thick_arms;   // руки
    float lg = cfg::esp::thick_legs;   // ноги

    float hcr = w * 0.22f;
    ImVec2 neck   (cx,             top + hcr * 2.0f);
    ImVec2 chest  (cx,             top + h * 0.28f);
    ImVec2 pelvis (cx,             top + h * 0.55f);
    ImVec2 l_shldr(cx - w*0.38f,  top + h * 0.28f);
    ImVec2 l_elbow(cx - w*0.44f,  top + h * 0.42f);
    ImVec2 l_hand (cx - w*0.38f,  top + h * 0.55f);
    ImVec2 r_shldr(cx + w*0.38f,  top + h * 0.28f);
    ImVec2 r_elbow(cx + w*0.44f,  top + h * 0.42f);
    ImVec2 r_hand (cx + w*0.38f,  top + h * 0.55f);
    ImVec2 l_hip  (cx - w*0.14f,  top + h * 0.55f);
    ImVec2 l_knee (cx - w*0.16f,  top + h * 0.76f);
    ImVec2 l_foot (cx - w*0.13f,  bot);
    ImVec2 r_hip  (cx + w*0.14f,  top + h * 0.55f);
    ImVec2 r_knee (cx + w*0.16f,  top + h * 0.76f);
    ImVec2 r_foot (cx + w*0.13f,  bot);

// Макрос: outline черным + цвет с заданной толщиной
#define TBONE(a, b, t) \
    dl->AddLine((a),(b), black, (t)+1.2f); \
    dl->AddLine((a),(b), col,   (t));

    // Позвоночник (самый толстый)
    TBONE(neck,    chest,   sp)
    TBONE(chest,   pelvis,  sp)

    // Ключицы (средние)
    TBONE(chest,   l_shldr, ar)
    TBONE(chest,   r_shldr, ar)

    // Руки (тонкие)
    TBONE(l_shldr, l_elbow, ar)
    TBONE(l_elbow, l_hand,  ar * 0.8f)
    TBONE(r_shldr, r_elbow, ar)
    TBONE(r_elbow, r_hand,  ar * 0.8f)

    // Таз (средний)
    TBONE(pelvis,  l_hip,   lg * 0.8f)
    TBONE(pelvis,  r_hip,   lg * 0.8f)

    // Ноги (толстые)
    TBONE(l_hip,   l_knee,  lg)
    TBONE(l_knee,  l_foot,  lg * 0.85f)
    TBONE(r_hip,   r_knee,  lg)
    TBONE(r_knee,  r_foot,  lg * 0.85f)

#undef TBONE

    // Суставы — кружки разного размера
    float js = sp * 0.7f;
    dl->AddCircleFilled(neck,    js,          col, 8);
    dl->AddCircleFilled(chest,   js,          col, 8);
    dl->AddCircleFilled(pelvis,  js,          col, 8);
    dl->AddCircleFilled(l_shldr, js*0.85f,   col, 7);
    dl->AddCircleFilled(r_shldr, js*0.85f,   col, 7);
    dl->AddCircleFilled(l_elbow, ar*0.6f,    col, 6);
    dl->AddCircleFilled(r_elbow, ar*0.6f,    col, 6);
    dl->AddCircleFilled(l_hand,  ar*0.5f,    col, 6);
    dl->AddCircleFilled(r_hand,  ar*0.5f,    col, 6);
    dl->AddCircleFilled(l_knee,  lg*0.55f,   col, 6);
    dl->AddCircleFilled(r_knee,  lg*0.55f,   col, 6);
    dl->AddCircleFilled(l_foot,  lg*0.4f,    col, 6);
    dl->AddCircleFilled(r_foot,  lg*0.4f,    col, 6);
}

// ── Mini Radar ────────────────────────────────────────────────────────────────
// Накапливаем точки за кадр, рисуем один раз после цикла.
// Используем static буфер — максимум 64 точки.
struct RadarDot { float rx; float ry; int hp; };
static RadarDot g_radar_dots[64];
static int      g_radar_dot_count = 0;

void visuals::radar_push(float rx, float ry, int hp)
{
    if (!cfg::esp::mini_radar) return;
    if (g_radar_dot_count >= 64) return;
    g_radar_dots[g_radar_dot_count].rx = rx;
    g_radar_dots[g_radar_dot_count].ry = ry;
    g_radar_dots[g_radar_dot_count].hp = hp;
    g_radar_dot_count++;
}

void visuals::dmini_radar(ImDrawList* dl, float local_yaw_deg)
{
    if (!cfg::esp::mini_radar) return;

    float sz  = cfg::esp::radar_size;
    float rng = cfg::esp::radar_range;

    // Позиция радара: правый нижний угол (отступ от края)
    float ox = g_sw - sz - cfg::esp::radar_x;
    float oy = g_sh - sz - cfg::esp::radar_y;

    // Фон
    dl->AddRectFilled(
        ImVec2(ox, oy), ImVec2(ox+sz, oy+sz),
        IM_COL32(0, 0, 0, 180), 6.f);
    dl->AddRect(
        ImVec2(ox, oy), ImVec2(ox+sz, oy+sz),
        IM_COL32(80, 80, 80, 220), 6.f, 0, 1.5f);

    // Перекрестие
    float half = sz * 0.5f;
    dl->AddLine(ImVec2(ox+half, oy+4.f),    ImVec2(ox+half, oy+sz-4.f),
                IM_COL32(50,50,50,150), 1.f);
    dl->AddLine(ImVec2(ox+4.f,  oy+half),   ImVec2(ox+sz-4.f, oy+half),
                IM_COL32(50,50,50,150), 1.f);

    // Кольца дистанции
    dl->AddCircle(ImVec2(ox+half, oy+half), half*0.33f,
                  IM_COL32(50,50,50,120), 32, 1.f);
    dl->AddCircle(ImVec2(ox+half, oy+half), half*0.66f,
                  IM_COL32(50,50,50,120), 32, 1.f);

    // Локальный игрок — жёлтый треугольник в центре
    float yaw_rad = local_yaw_deg * 3.14159f / 180.f;
    float ta = 6.f;
    ImVec2 tp1(ox+half + cosf(yaw_rad)*ta,        oy+half + sinf(yaw_rad)*ta);
    ImVec2 tp2(ox+half + cosf(yaw_rad+2.3f)*ta*0.5f, oy+half + sinf(yaw_rad+2.3f)*ta*0.5f);
    ImVec2 tp3(ox+half + cosf(yaw_rad-2.3f)*ta*0.5f, oy+half + sinf(yaw_rad-2.3f)*ta*0.5f);
    dl->AddTriangleFilled(tp1, tp2, tp3, IM_COL32(255,220,0,240));

    // Враги
    for (int i = 0; i < g_radar_dot_count; i++) {
        float rx = g_radar_dots[i].rx;
        float ry = g_radar_dots[i].ry;
        int   hp = g_radar_dots[i].hp;

        // rx, ry уже в метрах относительно local (передаём из draw())
        // Масштабируем на размер радара
        float px = ox + half + (rx / rng) * half;
        float py = oy + half + (ry / rng) * half;

        // Клипуем внутрь круга радара
        float ddx = px - (ox+half);
        float ddy = py - (oy+half);
        float dd  = sqrtf(ddx*ddx + ddy*ddy);
        if (dd > half - 4.f) {
            float sc = (half - 4.f) / dd;
            px = ox+half + ddx*sc;
            py = oy+half + ddy*sc;
        }

        // Цвет по HP
        float ht = (float)hp / 100.f;
        int rc = hp < 50 ? 255 : (int)((1.f - (ht-0.5f)*2.f)*255);
        int gc = hp > 50 ? 255 : (int)(ht*2.f*255);
        ImU32 dcol = IM_COL32(rc, gc, 0, 230);

        dl->AddCircleFilled(ImVec2(px, py), 3.5f, IM_COL32(0,0,0,200), 6);
        dl->AddCircleFilled(ImVec2(px, py), 2.5f, dcol, 6);
    }

    // Сброс буфера после рисования
    g_radar_dot_count = 0;
}

// ─────────────────────────────────────────────────────────────────────────────
//  MAIN DRAW LOOP
// ─────────────────────────────────────────────────────────────────────────────
void visuals::draw() {
    bool any = cfg::esp::box           ||
               cfg::esp::name          || cfg::esp::health      ||
               cfg::esp::health_text   || cfg::esp::distance    ||
               cfg::esp::line          || cfg::esp::head_circle ||
               cfg::esp::skeleton      || cfg::esp::box_fill    ||
               cfg::esp::snapline_head || cfg::esp::armor_bar   ||
               cfg::esp::skel_chams    || cfg::esp::device_tag  ||
               cfg::esp::thick_bones   || cfg::esp::mini_radar  ||
               cfg::esp::hp_color_box  || cfg::esp::hp_gradient_bar ||
               cfg::esp::danger_zone   || cfg::esp::offscreen   ||
               cfg::esp::player_count  || cfg::esp::closest_arrow ||
               cfg::esp::chams_body    || cfg::esp::hit_zone      ||
               cfg::esp::shadow_esp    || cfg::esp::footprints     ||
               cfg::crosshair::enabled;
    if (!any) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    // ── Crosshair (не привязан к игрокам) ────────────────────
    dcrosshair(dl);

    uint64_t PlayerManager = get_player_manager();
    if (!PlayerManager) return;

    uint64_t LocalPlayer = rpm<uint64_t>(PlayerManager + oxorany(OFF_PM_LOCAL_PLAYER));
    if (!LocalPlayer) return;

    matrix    ViewMatrix     = player::view_matrix(LocalPlayer);
    Vector3   LocalPosition  = player::position(LocalPlayer);
    int       LocalTeam      = rpm<uint8_t>(LocalPlayer + oxorany(OFF_PLAYER_TEAM));

    uint64_t PlayerList = rpm<uint64_t>(PlayerManager + oxorany(OFF_PM_PLAYER_LIST));
    if (!PlayerList) return;

    int PlayerCount = rpm<int>(PlayerList + oxorany(OFF_LIST_COUNT));
    if (PlayerCount <= 0 || PlayerCount > 64) return;

    uint64_t ListBuffer = rpm<uint64_t>(PlayerList + oxorany(OFF_LIST_BUFFER));
    if (!ListBuffer) return;

    for (int i = 0; i < PlayerCount; i++) {
        uint64_t Player = rpm<uint64_t>(
            ListBuffer + oxorany(OFF_LIST_ENTRY_BASE) +
            (uint64_t)oxorany(OFF_LIST_ENTRY_STRIDE) * (uint64_t)i);
        if (!Player || Player == LocalPlayer) continue;

        uint8_t PlayerTeam = rpm<uint8_t>(Player + oxorany(OFF_PLAYER_TEAM));
        if (PlayerTeam == (uint8_t)LocalTeam) continue;

        int Health = player::health(Player);
        // Armor bar — заглушка 0x000, подставь реальный оффсет в offsets.hpp
        int Armor = 0;
        if (OFF_PLAYER_ARMOR != 0x000) {
            Armor = rpm<int>(Player + oxorany(OFF_PLAYER_ARMOR));
            if (Armor < 0)   Armor = 0;
            if (Armor > 100) Armor = 100;
        }

        if (Health <= 0) continue;

        Vector3 PlayerPosition = player::position(Player);
        if (PlayerPosition.x == 0.f && PlayerPosition.y == 0.f &&
            PlayerPosition.z == 0.f) continue;

        float Distance = calculate_distance(PlayerPosition, LocalPosition);
        if (Distance > 500.f) continue;

        Vector3 HeadPosition(PlayerPosition.x,
                             PlayerPosition.y + PLAYER_HEIGHT,
                             PlayerPosition.z);

        ImVec2 ScreenHead, ScreenFoot;
        if (!world_to_screen(HeadPosition,    ViewMatrix, ScreenHead)) continue;
        if (!world_to_screen(PlayerPosition,  ViewMatrix, ScreenFoot)) continue;

        float bh = fabsf(ScreenFoot.y - ScreenHead.y);
        float bw = bh * 0.25f;
        float cx = (ScreenHead.x + ScreenFoot.x) * 0.5f;

        float y_top = ScreenHead.y < ScreenFoot.y ? ScreenHead.y : ScreenFoot.y;
        float y_bot = ScreenHead.y > ScreenFoot.y ? ScreenHead.y : ScreenFoot.y;

        ImRect r(ImVec2(cx - bw, y_top), ImVec2(cx + bw, y_bot));

        // порядок: fill → box → детали
        dbox_fill(dl, r);

        if (cfg::esp::box) {
            if (cfg::esp::box_type == 0) dbox_full  (dl, r, 1.f);
            else                         dbox_corner(dl, r, 1.f);
        }

        dline       (dl, r);
        dhead_circle(dl, r);
        ddist       (dl, r, Distance);

        if (cfg::esp::name) {
            read_string PlayerName = player::name(Player);
            std::string ns = PlayerName.as_utf8();
            if (!ns.empty()) dnick(dl, r, ns.c_str());
        }

        dhp_bar (dl, r, Health);
        dhp_text(dl, r, Health);
        dskeleton(dl, r);
        dsnapline_head(dl, r, ScreenHead);
        darmor_bar(dl, r, Armor);

        // ── Новые функции per-player ──────────────────────────
        dhp_color_box    (dl, r, Health);
        dhp_gradient_bar (dl, r, Health);
        ddanger_zone     (dl, r, Distance);
        doffscreen       (dl, ScreenHead, g_sw, g_sh, ScreenHead);
        dskel_chams      (dl, r, Health, Distance);
        dthick_bones     (dl, r);
        ddevice_tag      (dl, r, Player);

        // ── Chams Body / Hit Zone / Shadow ───────────────────
        dshadow_esp  (dl, r);          // тень — ДО бокса визуально
        dchams_body  (dl, r);          // заливка тела
        dhit_zone    (dl, r);          // хитбоксы
        footprint_push(Player, ScreenFoot);  // пишем след

        // Radar: передаём смещение от локального игрока
        // rx = X diff, ry = Z diff (горизонтальная плоскость)
        float rdx = PlayerPosition.x - LocalPosition.x;
        float rdz = PlayerPosition.z - LocalPosition.z;
        radar_push(rdx, rdz, Health);
    }

    // ── Overlay: после цикла ──────────────────────────────────
    // Player Count
    {
        static int visible_count = 0;
        // Считаем через g_radar_dot_count пока он ещё не сброшен
        // (dmini_radar сбросит после)
        // Используем отдельный счётчик
    }
    dfootprints   (dl);                       // следы — до всего остального
    dplayer_count (dl, g_radar_dot_count);   // до dmini_radar
    dclosest_arrow(dl, g_sw, g_sh,
                   ImVec2(g_sw*0.5f, g_sh*0.5f));   // заглушка: обновим ниже
    dmini_radar   (dl, 0.f);   // yaw = 0 заглушка (подставь реальный yaw)
}

