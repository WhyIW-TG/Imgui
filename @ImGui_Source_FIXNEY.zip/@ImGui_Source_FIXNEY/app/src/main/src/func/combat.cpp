#include "combat.hpp"
#include "../game/game.hpp"
#include "../game/offsets.hpp"
#include "../game/player.hpp"
#include "../game/math.hpp"
#include "../other/memory.hpp"
#include "../protect/oxorany.hpp"
#include "imgui.h"
#include <stdint.h>
#include <cstring>
#include <cmath>

// ─────────────────────────────────────────────────────────────────────────────
//  УТИЛИТЫ
// ─────────────────────────────────────────────────────────────────────────────

static inline bool valid_addr(uint64_t a) {
    return (a >= 0x10000 && a <= 0x7FFFFFFFFFFF);
}

// ─────────────────────────────────────────────────────────────────────────────
//  PUBLIC TICK
// ─────────────────────────────────────────────────────────────────────────────
void combat::tick(uint64_t lp) {
    if (!valid_addr(lp)) return;

    if (cfg::combat::aimbot) {
        aimbot_tick(lp);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  AIMBOT INTERNAL
// ─────────────────────────────────────────────────────────────────────────────

namespace aimbot_internal {
    static constexpr float kPi              = AIMBOT_PI;
    static constexpr float kVerticalFovDeg  = AIMBOT_VERTICAL_FOV_DEG;
    static constexpr float kRadToDeg        = AIMBOT_RAD_TO_DEG;

    static inline bool likely_ptr(uint64_t p) {
        return p > 0x10000ull && p < 0x0000FFFFFFFFFFFFull;
    }

    static float fov_radius_px(float fov_deg, float screen_h) {
        if (screen_h <= 0.f) return 0.f;
        float clamped = (fov_deg < 1.f) ? 1.f : (fov_deg > 179.f) ? 179.f : fov_deg;
        float half_v  = (kVerticalFovDeg * 0.5f) * (kPi / 180.f);
        float half_a  = (clamped         * 0.5f) * (kPi / 180.f);
        float tan_v   = tanf(half_v);
        if (fabsf(tan_v) < 0.00001f) return 0.f;
        return ((screen_h * 0.5f) / tan_v) * tanf(half_a);
    }

    static Vector3 target_point(uint64_t player_ptr, const Vector3& p) {
        Vector3 bone{};
        if (player::bone_position(player_ptr, 1, p, bone)) return bone;
        return Vector3(p.x, p.y + 1.4f, p.z);
    }

    static float normalize_yaw(float yaw) {
        while (yaw >  180.f) yaw -= 360.f;
        while (yaw < -180.f) yaw += 360.f;
        return yaw;
    }

    static float smooth_angle(float current, float target, float smooth) {
        return normalize_yaw(current + normalize_yaw(target - current) * smooth);
    }

    static bool find_int_property(uint64_t player_ptr, const char* tag, int& out_value) {
        uint64_t photon_player = player::photon_ptr(player_ptr);
        if (!photon_player) return false;

        uint64_t props_reg = rpm<uint64_t>(photon_player + oxorany(OFF_PHOTON_PROPS_REG));
        if (!props_reg) return false;

        int count = rpm<int>(props_reg + oxorany(OFF_PROPS_COUNT));
        if (count <= 0 || count > 128) return false;

        uint64_t props_list = rpm<uint64_t>(props_reg + oxorany(OFF_PROPS_LIST));
        if (!props_list) return false;

        for (int i = 0; i < count; i++) {
            uint64_t key = rpm<uint64_t>(props_list + oxorany(OFF_PROPS_KEY_BASE) +
                                         oxorany(OFF_LIST_ENTRY_STRIDE) * i);
            uint64_t val = rpm<uint64_t>(props_list + oxorany(OFF_PROPS_VAL_BASE) +
                                         oxorany(OFF_LIST_ENTRY_STRIDE) * i);
            if (!key || !val) continue;

            std::string ks = rpm<read_string>(key).as_utf8();
            if (ks.empty()) continue;

            if (std::strstr(ks.c_str(), tag)) {
                out_value = rpm<int>(val + oxorany(OFF_PROPS_VALUE_DATA));
                return true;
            }
        }
        return false;
    }

    static bool pass_visible_check(uint64_t player_ptr) {
        if (!cfg::combat::aimbot_visible) return true;

        int state = player::visibility_state(player_ptr);
        if (state == 2) return true;
        if (state == 1) return false;

        int value = 0;
        if (find_int_property(player_ptr, "visible",    value) ||
            find_int_property(player_ptr, "Visible",    value) ||
            find_int_property(player_ptr, "isVisible",  value) ||
            find_int_property(player_ptr, "is_visible", value)) {
            return value != 0;
        }
        if (find_int_property(player_ptr, "occluded",   value) ||
            find_int_property(player_ptr, "Occluded",   value) ||
            find_int_property(player_ptr, "isOccluded", value)) {
            return value == 0;
        }
        return true;
    }
} // namespace aimbot_internal

// ─────────────────────────────────────────────────────────────────────────────
//  AIMBOT TICK
// ─────────────────────────────────────────────────────────────────────────────
void combat::aimbot_tick(uint64_t lp) {
    using namespace aimbot_internal;

    if (!cfg::combat::aimbot) return;
    if (!valid_addr(lp)) return;

    float smooth_setting = cfg::combat::aimbot_smooth;
    if (smooth_setting < 0.f) smooth_setting = 0.f;
    if (smooth_setting > 1.f) smooth_setting = 1.f;
    bool hard_lock_mode = (smooth_setting <= 0.0001f);

    uint64_t PlayerManager = get_player_manager();
    if (!PlayerManager) return;

    matrix  ViewMatrix     = player::view_matrix(lp);
    Vector3 LocalPosition  = player::position(lp);
    int     LocalTeam      = rpm<uint8_t>(lp + oxorany(OFF_PLAYER_TEAM));

    uint64_t PlayerList = rpm<uint64_t>(PlayerManager + oxorany(OFF_PM_PLAYER_LIST));
    if (!PlayerList) return;

    int PlayerCount = rpm<int>(PlayerList + oxorany(OFF_LIST_COUNT));
    if (PlayerCount <= 0 || PlayerCount > 64) return;

    uint64_t ListBuffer = rpm<uint64_t>(PlayerList + oxorany(OFF_LIST_BUFFER));
    if (!ListBuffer) return;

    const ImVec2 center(g_sw * 0.5f, g_sh * 0.5f);
    const float  radius     = fov_radius_px(cfg::combat::aimbot_fov, g_sh);
    float        best_dist  = radius + 1.f;
    ImVec2       best_screen(0.f, 0.f);
    Vector3      best_world(0.f, 0.f, 0.f);
    bool         found      = false;

    for (int i = 0; i < PlayerCount; i++) {
        uint64_t Player = rpm<uint64_t>(
            ListBuffer + oxorany(OFF_LIST_ENTRY_BASE) +
            oxorany(OFF_LIST_ENTRY_STRIDE) * i);
        if (!Player || Player == lp) continue;

        uint8_t PlayerTeam = rpm<uint8_t>(Player + oxorany(OFF_PLAYER_TEAM));
        if (PlayerTeam == static_cast<uint8_t>(LocalTeam)) continue;

        int Health = player::health(Player);
        if (Health <= 0) continue;

        Vector3 Position = player::position(Player);
        if (Position.x == 0.f && Position.y == 0.f && Position.z == 0.f) continue;

        float Distance = calculate_distance(Position, LocalPosition);
        if (Distance > cfg::combat::aimbot_max_dist) continue;

        if (!pass_visible_check(Player)) continue;

        Vector3 TargetPoint = target_point(Player, Position);
        ImVec2  ScreenPos;
        if (!world_to_screen(TargetPoint, ViewMatrix, ScreenPos)) continue;

        float dx = ScreenPos.x - center.x;
        float dy = ScreenPos.y - center.y;
        float d  = sqrtf(dx * dx + dy * dy);

        if (d <= radius && d < best_dist) {
            best_dist   = d;
            best_screen = ScreenPos;
            best_world  = TargetPoint;
            found       = true;
        }
    }

    if (!found) return;

    // Визуалы — линия и точка к цели
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    if (dl) {
        if (cfg::combat::aimbot_lock_line) {
            dl->AddLine(center, best_screen, IM_COL32(0,   0,   0,   180), 2.f);
            dl->AddLine(center, best_screen, IM_COL32(255, 255, 255, 220), 1.f);
        }
        if (cfg::combat::aimbot_lock_dot) {
            dl->AddCircleFilled(best_screen, 3.5f, IM_COL32(255, 255, 255, 230), 12);
            dl->AddCircle(      best_screen, 5.5f, IM_COL32(0,   0,   0,   170), 14, 1.f);
        }
    }

    // Запись углов
    uint64_t aim_controller = rpm<uint64_t>(lp + oxorany(OFF_PLAYER_AIM_CONTROLLER));
    if (!aim_controller) return;

    uint64_t aiming_data = rpm<uint64_t>(aim_controller + oxorany(OFF_AIM_CONTROLLER_DATA));
    if (!aiming_data) return;

    // 1.21f = высота глаз локального игрока над feet (подобрано эмпирически)
    Vector3 cam_pos(LocalPosition.x, LocalPosition.y + 1.18f, LocalPosition.z);
    float dx_aim = best_world.x - cam_pos.x;
    float dy_aim = best_world.y - cam_pos.y;
    float dz_aim = best_world.z - cam_pos.z;
    float dist   = sqrtf(dx_aim*dx_aim + dy_aim*dy_aim + dz_aim*dz_aim);
    if (dist < 0.001f) return;

    float s = dy_aim / dist;
    if (s < -1.f) s = -1.f;
    if (s >  1.f) s =  1.f;

    float pitch = -asinf(s) * kRadToDeg;
    float yaw   = normalize_yaw(atan2f(dx_aim, dz_aim) * kRadToDeg);

    float out_pitch = pitch;
    float out_yaw   = yaw;

    if (!hard_lock_mode) {
        float cur_pitch = rpm<float>(aiming_data + oxorany(OFF_AIMDATA_PITCH));
        float cur_yaw   = normalize_yaw(rpm<float>(aiming_data + oxorany(OFF_AIMDATA_YAW)));
        float smooth    = (smooth_setting < 0.0001f) ? 0.0001f : smooth_setting;
        out_pitch = cur_pitch + (pitch - cur_pitch) * smooth;
        out_yaw   = smooth_angle(cur_yaw, yaw, smooth);
    }

    float vec[3] = { out_pitch, out_yaw, 0.f };

    wpm<float>(aiming_data + oxorany(OFF_AIMDATA_PITCH), out_pitch);
    wpm<float>(aiming_data + oxorany(OFF_AIMDATA_YAW),   out_yaw);
    mem_write(aiming_data + oxorany(OFF_AIMDATA_PITCH_YAW_VEC3), vec, sizeof(vec));
    mem_write(aiming_data + oxorany(OFF_AIMDATA_SECOND_VEC3),    vec, sizeof(vec));
}

// ─────────────────────────────────────────────────────────────────────────────
//  AIMBOT DRAW FOV
// ─────────────────────────────────────────────────────────────────────────────
void combat::aimbot_draw_fov(void* draw_list, float screen_w, float screen_h) {
    using namespace aimbot_internal;

    if (!draw_list || !cfg::combat::aimbot || !cfg::combat::aimbot_fov_draw) return;
    if (screen_w <= 0.f || screen_h <= 0.f) return;

    ImDrawList* dl = (ImDrawList*)draw_list;
    float cx     = screen_w * 0.5f;
    float cy     = screen_h * 0.5f;
    float radius = fov_radius_px(cfg::combat::aimbot_fov, screen_h);

    dl->AddCircle(ImVec2(cx, cy), radius, IM_COL32(0,   0,   0,   130), 64, 2.f);
    dl->AddCircle(ImVec2(cx, cy), radius, IM_COL32(255, 255, 255, 180), 64, 1.f);
}

