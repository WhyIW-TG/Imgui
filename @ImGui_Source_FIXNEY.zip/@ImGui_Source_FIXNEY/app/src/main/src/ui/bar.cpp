#include "bar.hpp"
#include "theme/theme.hpp"
#include "Android_draw/draw.h"
#include "imgui.h"
#include "imgui_internal.h"
#include <cmath>

// ─────────────────────────────────────────────────────────────────────────────
//  AzenWin — Watermark (refactored 0.39.1)
//  Минималистичный, строгий стиль: чёрный фон, тонкая нейтральная рамка,
//  акцентная вертикальная риска слева, моноширинный текст с разделителем «·».
//  Без пульсаций яркости и бликов — только мягкая hover/press реакция.
// ─────────────────────────────────────────────────────────────────────────────

namespace ui::bar {

    static float lrp(float a, float b, float t) { return a + (b - a) * t; }
    static float ease(float t) { return -(cosf(3.14159265f * t) - 1.f) / 2.f; }

    static float wm_hover_a = 0.f;
    static float wm_press_a = 0.f;

    void  set_game_alpha(float a) { g_game_alpha = a; }
    float game_alpha()            { return g_game_alpha; }

    void render() {
        if (g_game_alpha < 0.001f) return;

        ImGuiIO& io = ImGui::GetIO();
        float    dt = io.DeltaTime;

        static bool  state = true;
        static float prog  = 0.f;
        static float lt    = 0.f;

        float ct = ImGui::GetTime();

        // ── Содержимое watermark ────────────────────────────────────────────
        //   [ ▌ AZENWIN · EXTERNAL ]
        static const char* WM_BRAND = "AZENWIN";
        static const char* WM_SEP   = " \xC2\xB7 ";   // UTF-8 middle dot (U+00B7)
        static const char* WM_SUB   = "EXTERNAL";

        ImFont* wm_font = (fontMedium != nullptr) ? fontMedium : ImGui::GetFont();

        // Внутренние отступы (квадратные, для аккуратной формы)
        const float pad_x = 14.f;
        const float pad_y = 8.f;
        // Толщина акцентной риски слева
        const float strip_w = 3.f;
        // Отступ между риской и текстом
        const float strip_gap = 10.f;

        ImGui::PushFont(wm_font);
        float w_brand = ImGui::CalcTextSize(WM_BRAND).x;
        float w_sep   = ImGui::CalcTextSize(WM_SEP).x;
        float w_sub   = ImGui::CalcTextSize(WM_SUB).x;
        float fh2     = wm_font->FontSize;
        ImGui::PopFont();

        float total_w = w_brand + w_sep + w_sub;
        float box_w   = pad_x + strip_w + strip_gap + total_w + pad_x;
        float box_h   = fh2 + pad_y * 2.f;

        const float bx = 14.f;
        const float by = 14.f;

        ImRect wm_rect(ImVec2(bx, by), ImVec2(bx + box_w, by + box_h));

        // ── Невидимое окно-кнопка (touch-зона) ─────────────────────────────
        ImGui::SetNextWindowPos(wm_rect.Min);
        ImGui::SetNextWindowSize(ImVec2(box_w, box_h));
        ImGui::SetNextWindowBgAlpha(0.f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,    ImVec2(0, 0));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.f);
        ImGui::Begin("##wm_touch", nullptr,
            ImGuiWindowFlags_NoTitleBar   |
            ImGuiWindowFlags_NoDecoration |
            ImGuiWindowFlags_NoBackground |
            ImGuiWindowFlags_NoMove       |
            ImGuiWindowFlags_NoResize     |
            ImGuiWindowFlags_NoNav);

        ImGui::SetCursorScreenPos(wm_rect.Min);
        bool pressed = ImGui::InvisibleButton("##wm_btn",
            ImVec2(box_w, box_h),
            ImGuiButtonFlags_MouseButtonLeft);
        bool hov_wm  = ImGui::IsItemHovered();

        if (pressed) {
            if (ct - lt >= 0.15f) {
                state      = !state;
                lt         = ct;
                wm_press_a = 1.f;
            }
        }

        ImGui::End();
        ImGui::PopStyleVar(2);

        // ── Анимация открытия меню (внешний контракт остаётся) ─────────────
        float tgt = state ? 0.f : 1.f;
        float spd = 12.f * dt;
        if (prog < tgt) prog = ImMin(prog + spd, tgt);
        else            prog = ImMax(prog - spd, tgt);
        prog   = ImClamp(prog, 0.f, 1.f);
        g_alpha = ease(prog);
        g_open  = g_alpha > 0.2f;

        // Мягкая интерполяция hover/press
        float ha_tgt = hov_wm ? 1.f : 0.f;
        float ha_spd = (hov_wm ? 14.f : 8.f) * dt;
        if (ha_spd > 1.f) ha_spd = 1.f;
        wm_hover_a = lrp(wm_hover_a, ha_tgt, ha_spd);
        wm_press_a = lrp(wm_press_a, 0.f, ImClamp(8.f * dt, 0.f, 1.f));

        // ── Рисуем ─────────────────────────────────────────────────────────
        ImDrawList* fg = ImGui::GetBackgroundDrawList();
        const float ga = g_game_alpha;
        const float R  = 4.f;  // строгие, едва скруглённые углы

        // Drop-shadow (один слой, мягкий)
        fg->AddRectFilled(
            ImVec2(bx - 2.f, by + 2.f),
            ImVec2(bx + box_w + 2.f, by + box_h + 4.f),
            IM_COL32(0, 0, 0, (int)(70 * ga)), R + 2.f);

        // Основной фон — почти чёрный, высокая непрозрачность
        fg->AddRectFilled(
            ImVec2(bx, by), ImVec2(bx + box_w, by + box_h),
            IM_COL32(10, 10, 11, (int)(238 * ga)), R);

        // Hover/press subtle overlay (нейтрально-светлая заливка)
        if (wm_hover_a > 0.01f || wm_press_a > 0.01f) {
            float oa = wm_hover_a * 0.06f + wm_press_a * 0.10f;
            fg->AddRectFilled(
                ImVec2(bx, by), ImVec2(bx + box_w, by + box_h),
                IM_COL32(255, 255, 255, (int)(255 * oa * ga)), R);
        }

        // Тонкая рамка — нейтральный графит, без акцента
        fg->AddRect(
            ImVec2(bx, by), ImVec2(bx + box_w, by + box_h),
            IM_COL32(48, 48, 52, (int)(220 * ga)),
            R, 0, 1.f);
        // Внутренняя highlight-линия 1px (микро-rim)
        fg->AddRect(
            ImVec2(bx + 1.f, by + 1.f),
            ImVec2(bx + box_w - 1.f, by + box_h - 1.f),
            IM_COL32(255, 255, 255, (int)(10 * ga)),
            R - 1.f, 0, 1.f);

        // Акцентная вертикальная риска слева — индикатор состояния меню
        {
            float sx0 = bx + pad_x * 0.5f;
            float sy0 = by + pad_y * 0.6f;
            float sy1 = by + box_h - pad_y * 0.6f;
            // Интенсивность зависит от открытого состояния меню (g_alpha) и press
            float strip_brt = 0.55f + g_alpha * 0.35f + wm_press_a * 0.10f;
            if (strip_brt > 1.f) strip_brt = 1.f;
            fg->AddRectFilled(
                ImVec2(sx0, sy0),
                ImVec2(sx0 + strip_w, sy1),
                IM_COL32(
                    (int)(clr::accent.x * 255.f * strip_brt),
                    (int)(clr::accent.y * 255.f * strip_brt),
                    (int)(clr::accent.z * 255.f * strip_brt),
                    (int)(245 * ga)),
                1.f);
        }

        // ── Текст ──────────────────────────────────────────────────────────
        ImGui::PushFont(wm_font);
        float ty = by + pad_y;
        float tx = bx + pad_x + strip_w + strip_gap;

        // AZENWIN — основной, светлый
        fg->AddText(
            ImVec2(tx, ty),
            IM_COL32(232, 232, 234, (int)(240 * ga)),
            WM_BRAND);
        tx += w_brand;

        // Разделитель — приглушённый акцент
        fg->AddText(
            ImVec2(tx, ty),
            IM_COL32(
                (int)(clr::accent.x * 255.f),
                (int)(clr::accent.y * 255.f),
                (int)(clr::accent.z * 255.f),
                (int)(200 * ga)),
            WM_SEP);
        tx += w_sep;

        // EXTERNAL — графит
        fg->AddText(
            ImVec2(tx, ty),
            IM_COL32(120, 120, 124, (int)(220 * ga)),
            WM_SUB);

        ImGui::PopFont();

        // ── Status dot (правый верх) ───────────────────────────────────────
        // Маленький индикатор: открыто (акцент) / закрыто (графит)
        {
            float dot_r = 2.5f;
            float dot_x = bx + box_w - 8.f;
            float dot_y = by + 8.f;
            float oa    = g_alpha;
            ImU32 dot_c = IM_COL32(
                (int)(lrp(70.f,  clr::accent_light.x * 255.f, oa)),
                (int)(lrp(70.f,  clr::accent_light.y * 255.f, oa)),
                (int)(lrp(72.f,  clr::accent_light.z * 255.f, oa)),
                (int)(225 * ga));
            fg->AddCircleFilled(ImVec2(dot_x, dot_y), dot_r, dot_c, 12);
            if (oa > 0.05f) {
                fg->AddCircleFilled(
                    ImVec2(dot_x, dot_y), dot_r + 3.f,
                    IM_COL32(
                        (int)(clr::accent.x * 255.f),
                        (int)(clr::accent.y * 255.f),
                        (int)(clr::accent.z * 255.f),
                        (int)(40 * oa * ga)),
                    16);
            }
        }
    }

} // namespace ui::bar
