#pragma once
#include "imgui.h"
#include "imgui_internal.h"
#include <string>
#include <unordered_map>
#include <functional>

inline float g_sw, g_sh;

namespace ui {

namespace clr {
    // ── AzenWin — строгая чёрная тема, акцент красный (настраиваемый) ────
    inline ImVec4 bg           = ImVec4(8/255.f,    8/255.f,    8/255.f,  0.99f);
    inline ImVec4 bg_two       = ImVec4(12/255.f,   12/255.f,   12/255.f, 0.98f);
    inline ImVec4 sidebar      = ImVec4(10/255.f,   10/255.f,   10/255.f, 0.99f);
    inline ImVec4 panel        = ImVec4(18/255.f,   18/255.f,   18/255.f, 0.97f);
    inline ImVec4 widget       = ImVec4(28/255.f,   28/255.f,   28/255.f, 0.90f);
    // Accent — по умолчанию красный, меняется через cfg_accent_color
    inline ImVec4 accent       = ImVec4(220/255.f,  30/255.f,   30/255.f, 0.92f);
    inline ImVec4 accent_light = ImVec4(255/255.f,  70/255.f,   70/255.f, 1.0f);
    inline ImVec4 accent_dark  = ImVec4(100/255.f,  12/255.f,   12/255.f, 0.40f);
    inline ImVec4 text         = ImVec4(220/255.f,  220/255.f,  220/255.f, 1.f);
    inline ImVec4 text_light   = ImVec4(255/255.f,  255/255.f,  255/255.f, 1.f);
    inline ImVec4 text_dim     = ImVec4(80/255.f,   80/255.f,   80/255.f,  1.f);
    inline ImVec4 border       = ImVec4(28/255.f,   28/255.f,   28/255.f,  0.90f);
    inline ImVec4 border_light = ImVec4(255/255.f,  255/255.f,  255/255.f, 0.04f);
    inline ImVec4 border_dark  = ImVec4(0/255.f,    0/255.f,    0/255.f,   1.f);
    inline ImVec4 subtab_bg    = ImVec4(12/255.f,   12/255.f,   12/255.f,  0.98f);
}

namespace style {
    inline std::unordered_map<std::string, float>   anims;
    inline std::unordered_map<std::string, ImVec4>  anim_colors;
    inline float content_w     = 0.f;
    inline float content_alpha = 1.f;
    inline bool  popup_open    = false;
    inline std::string active_popup = "";
    inline constexpr float S = 2.5f;

    // ── Customization ────────────────────────────────────────────────────
    inline float cfg_menu_opacity     = 1.0f;
    inline float cfg_win_rounding     = 8.f;
    inline bool  cfg_corner_dots      = false;
    inline float cfg_corner_dot_size  = 3.0f;
    inline bool  cfg_inner_shine      = false;
    inline bool  cfg_rgb_menu         = false;
    inline float cfg_rgb_speed        = 1.0f;
    // Дефолт — чистый красный
    inline ImVec4 cfg_accent_color    = ImVec4(220.f/255.f, 30.f/255.f, 30.f/255.f, 1.f);
    inline int   cfg_font_idx         = 1;
    inline float cfg_font_scale       = 1.0f;
    // 0=None 1=Snow 2=Rain 3=Stars
    inline int   cfg_anim_type        = 0;
    inline float cfg_anim_speed       = 1.0f;
    inline int   cfg_anim_count       = 80;
    inline float cfg_open_speed       = 6.0f;
    inline float cfg_tab_fade_speed   = 10.0f;

    void   tick();
    float  anim(const std::string& id, float tgt, float spd = 12.f);
    ImVec4 anim_col(const std::string& id, const ImVec4& tgt, float spd = 12.f);
    ImU32  col(const ImVec4& c, float a = 1.f);
    bool   popup();
    void   close();
    void   popups();
}

} // namespace ui
