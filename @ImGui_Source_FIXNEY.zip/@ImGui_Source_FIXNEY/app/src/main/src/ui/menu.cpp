#define IMGUI_DEFINE_MATH_OPERATORS
namespace touch { extern float g_menu_x, g_menu_y, g_menu_w, g_menu_h; extern bool g_menu_open; }
#include "menu.hpp"
#include "bar.hpp"
#include "cfg.hpp"
#include "cfg_holy.hpp"
#include "../func/combat.hpp"
#include "theme/theme.hpp"
#include "widgets/widgets.hpp"
#include "imgui.h"
#include "imgui_internal.h"
#include "Android_draw/draw.h"
#include "esp_preview.hpp"
#include "mode_select.hpp"
#include <cmath>
#include <ctime>
#include <cstdlib>

namespace ui::menu {
    using namespace style;
    using namespace widgets;

    static float  ma             = 0.f;
    static float  cfg_anim_count_f = 80.f;
    static int    tab            = 0;
    static bool   drag           = false;
    static ImVec2 doff           = ImVec2(0, 0);
    static float  scr_tgt        = 0.f;
    static float  scr_cur        = 0.f;
    static float  ta             = 1.f;
    static bool   tsw            = false;
    static int    ttab           = 0;

    // ── Размеры окна (top-tabs layout) ───────────────────────────────────
    //   sidebar убран; вкладки размещены в header горизонтально.
    //   sw оставлен (=0) ради бинарной совместимости с возможными
    //   внешними настройками cfg, но в layout не участвует.
    static float mw  = 980.f;
    static float mh  = 620.f;
    static float sw  = 0.f;    // legacy, не используется
    static float hh  = 62.f;   // высота top-bar (brand + tabs)
    static float fh  = 32.f;   // высота footer

    // Вкладки — добавили Holy
    static const char* tabs[] = { "Aimbot", "Visuals", "Holy", "Settings" };
    static constexpr int tc   = sizeof(tabs) / sizeof(tabs[0]);

    static float lrp(float a, float b, float t) { return a + (b - a) * t; }

    // ── Тень ─────────────────────────────────────────────────────────────────
    static void shadow(ImVec2 p, ImVec2 s, float a) {
        if (a < 0.01f) return;
        ImDrawList* bg = ImGui::GetBackgroundDrawList();
        bg->AddRectFilled(ImVec2(p.x-4,  p.y-4),  ImVec2(p.x+s.x+4,  p.y+s.y+4),  IM_COL32(0,0,0,(int)(60*a)),  10.f);
        bg->AddRectFilled(ImVec2(p.x-8,  p.y-8),  ImVec2(p.x+s.x+8,  p.y+s.y+8),  IM_COL32(0,0,0,(int)(40*a)), 12.f);
        bg->AddRectFilled(ImVec2(p.x-14, p.y-14), ImVec2(p.x+s.x+14, p.y+s.y+14), IM_COL32(0,0,0,(int)(20*a)), 16.f);
        bg->AddRectFilled(ImVec2(p.x-20, p.y-20), ImVec2(p.x+s.x+20, p.y+s.y+20), IM_COL32(0,0,0,(int)(8*a)),  20.f);
    }

    // ── Секция-заголовок (строгая линия + текст) ──────────────────────────────
    static void section(const char* label, float a) {
        ImGuiWindow* w  = ImGui::GetCurrentWindow();
        ImDrawList*  dl = w->DrawList;
        ImVec2 sp = w->DC.CursorPos;
        float  ww = content_w > 0 ? content_w : ImGui::GetContentRegionAvail().x;

        // Линия до текста и после
        ImGui::PushFont(fontDesc);
        ImVec2 tsz = ImGui::CalcTextSize(label);
        float line_y = sp.y + tsz.y * 0.5f;
        float lpad   = 6.f;
        // Левая линия
        dl->AddLine(
            ImVec2(sp.x, line_y),
            ImVec2(sp.x + lpad, line_y),
            IM_COL32(
                (int)(clr::accent.x*255*0.5f),
                (int)(clr::accent.y*255*0.5f),
                (int)(clr::accent.z*255*0.5f),
                (int)(120*a)));
        // Текст
        dl->AddText(ImVec2(sp.x + lpad + 4.f, sp.y),
            IM_COL32(
                (int)(clr::accent.x*255*0.9f),
                (int)(clr::accent.y*255*0.9f),
                (int)(clr::accent.z*255*0.9f),
                (int)(200*a)),
            label);
        // Правая линия
        float after_x = sp.x + lpad + 4.f + tsz.x + 6.f;
        dl->AddLine(
            ImVec2(after_x, line_y),
            ImVec2(sp.x + ww, line_y),
            IM_COL32(
                (int)(clr::accent.x*255*0.15f),
                (int)(clr::accent.y*255*0.15f),
                (int)(clr::accent.z*255*0.15f),
                (int)(80*a)));
        ImGui::PopFont();
        ImGui::Dummy(ImVec2(0, tsz.y + 6.f));
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  AIMBOT TAB
    // ─────────────────────────────────────────────────────────────────────────
    static void aimbot_tab(float a) {
        section("AIMBOT", a);
        checkbox("Aimbot", &cfg::combat::aimbot, a);
        if (cfg::combat::aimbot) {
            separator(a);
            slider("FOV", &cfg::combat::aimbot_fov, 10.f, 180.f, a, "%.0f");
            separator(a);
            slider("Smooth", &cfg::combat::aimbot_smooth, 0.f, 1.f, a, "%.2f");
            separator(a);
            slider("Max Distance", &cfg::combat::aimbot_max_dist, 50.f, 500.f, a, "%.0f");
            separator(a);
            checkbox("Visible Check", &cfg::combat::aimbot_visible, a);
            separator(a);
            checkbox("FOV Circle", &cfg::combat::aimbot_fov_draw, a);
            separator(a);
            checkbox("Lock Line", &cfg::combat::aimbot_lock_line, a);
            separator(a);
            checkbox("Lock Dot", &cfg::combat::aimbot_lock_dot, a);
        }
        separator(a);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  VISUALS TAB
    // ─────────────────────────────────────────────────────────────────────────
    static void visuals_tab(float a) {
        section("ESP PREVIEW", a);
        checkbox("ESP Preview Window", &cfg::esp::preview_visible, a);
        separator(a);

        section("BOX", a);
        checkbox("Box", &cfg::esp::box, a);
        if (cfg::esp::box) {
            separator(a);
            spinner("Box type",    &cfg::esp::box_type,     {"Full", "Corner"}, a);
            separator(a);
            slider("Box rounding", &cfg::esp::box_rounding, 0.f, 10.f, a, "%.0f");
            separator(a);
            colorpick("Box color", &cfg::esp::box_col, a);
            checkbox("Box RGB",    &cfg::esp::box_rgb, a);
        }
        separator(a);

        checkbox("Head circle", &cfg::esp::head_circle, a);
        if (cfg::esp::head_circle) {
            separator(a);
            colorpick("Head color", &cfg::esp::head_circle_col, a);
            checkbox("Head RGB",    &cfg::esp::head_circle_rgb, a);
        }
        separator(a);

        checkbox("Skeleton", &cfg::esp::skeleton, a);
        if (cfg::esp::skeleton) {
            separator(a);
            colorpick("Skeleton color", &cfg::esp::skeleton_col, a);
            checkbox("Skeleton RGB",    &cfg::esp::skeleton_rgb, a);
        }
        separator(a);

        checkbox("Box fill", &cfg::esp::box_fill, a);
        if (cfg::esp::box_fill) {
            separator(a);
            slider("Fill alpha", &cfg::esp::fill_alpha, 0.f, 1.f, a, "%.2f");
            separator(a);
            spinner("Fill type", &cfg::esp::fill_type, {"Normal", "Gradient"}, a);
            separator(a);
            if (cfg::esp::fill_type == 0) {
                colorpick("Fill color", &cfg::esp::fill_col, a);
                checkbox("Fill RGB",    &cfg::esp::fill_rgb, a);
            } else {
                colorpick("Fill top",    &cfg::esp::fill_col_top, a);
                separator(a);
                colorpick("Fill bottom", &cfg::esp::fill_col_bot, a);
                separator(a);
                checkbox("Fill RGB",     &cfg::esp::fill_rgb, a);
            }
        }
        separator(a);

        checkbox("Name",    &cfg::esp::name, a);
        if (cfg::esp::name) {
            separator(a);
            colorpick("Name color", &cfg::esp::name_col, a);
            checkbox("Name RGB",    &cfg::esp::name_rgb, a);
        }
        separator(a);

        checkbox("Health bar", &cfg::esp::health, a);
        if (cfg::esp::health) {
            separator(a);
            colorpick("HP bar color", &cfg::esp::health_col, a);
            checkbox("HP bar RGB",    &cfg::esp::health_rgb, a);
        }
        separator(a);

        checkbox("Health text", &cfg::esp::health_text, a);
        if (cfg::esp::health_text) {
            separator(a);
            colorpick("HP text color", &cfg::esp::hptext_col, a);
            checkbox("HP text RGB",    &cfg::esp::hptext_rgb, a);
        }
        separator(a);

        checkbox("Distance", &cfg::esp::distance, a);
        if (cfg::esp::distance) {
            separator(a);
            colorpick("Distance color", &cfg::esp::distance_col, a);
            checkbox("Distance RGB",    &cfg::esp::distance_rgb, a);
        }
        separator(a);

        checkbox("Line", &cfg::esp::line, a);
        if (cfg::esp::line) {
            separator(a);
            colorpick("Line color", &cfg::esp::line_col, a);
            checkbox("Line RGB",    &cfg::esp::line_rgb, a);
        }
        separator(a);

        checkbox("Snapline to Head", &cfg::esp::snapline_head, a);
        if (cfg::esp::snapline_head) {
            separator(a);
            colorpick("Snapline color", &cfg::esp::snapline_head_col, a);
            checkbox("Snapline RGB",    &cfg::esp::snapline_head_rgb, a);
        }
        separator(a);

        checkbox("Armor Bar", &cfg::esp::armor_bar, a);
        if (cfg::esp::armor_bar) {
            separator(a);
            colorpick("Armor color", &cfg::esp::armor_bar_col, a);
            checkbox("Armor RGB",    &cfg::esp::armor_bar_rgb, a);
        }
        separator(a);

        // ── Device Tag ────────────────────────────────────────
        checkbox("Device Tag (iOS/APK)", &cfg::esp::device_tag, a);
        separator(a);

        // ── HP Color Box ──────────────────────────────────────
        checkbox("HP Color Box", &cfg::esp::hp_color_box, a);
        separator(a);

        // ── HP Gradient Bar ───────────────────────────────────
        checkbox("HP Gradient Bar", &cfg::esp::hp_gradient_bar, a);
        separator(a);

        // ── Danger Zone ───────────────────────────────────────
        checkbox("Danger Zone", &cfg::esp::danger_zone, a);
        if (cfg::esp::danger_zone) {
            separator(a);
            slider("Danger Distance", &cfg::esp::danger_zone_dist, 5.f, 100.f, a, "%.0fm");
            colorpick("Danger Color",  &cfg::esp::danger_zone_col,  a);
        }
        separator(a);

        // ── Offscreen Indicator ───────────────────────────────
        checkbox("Offscreen Indicator", &cfg::esp::offscreen, a);
        if (cfg::esp::offscreen) {
            separator(a);
            colorpick("Offscreen Color", &cfg::esp::offscreen_col, a);
        }
        separator(a);

        // ── Player Count ──────────────────────────────────────
        checkbox("Player Count", &cfg::esp::player_count, a);
        separator(a);

        // ── Closest Arrow ─────────────────────────────────────
        checkbox("Closest Arrow", &cfg::esp::closest_arrow, a);
        if (cfg::esp::closest_arrow) {
            separator(a);
            colorpick("Arrow Color", &cfg::esp::closest_arrow_col, a);
        }
        separator(a);

        // ── Thick Bones ───────────────────────────────────────
        checkbox("Thick Bones", &cfg::esp::thick_bones, a);
        if (cfg::esp::thick_bones) {
            separator(a);
            slider("Spine Thick", &cfg::esp::thick_spine, 1.f, 6.f, a, "%.1f");
            slider("Arms Thick",  &cfg::esp::thick_arms,  1.f, 4.f, a, "%.1f");
            slider("Legs Thick",  &cfg::esp::thick_legs,  1.f, 5.f, a, "%.1f");
        }
        separator(a);

        // ── Mini Radar ────────────────────────────────────────
        checkbox("Mini Radar", &cfg::esp::mini_radar, a);
        if (cfg::esp::mini_radar) {
            separator(a);
            slider("Radar Size",  &cfg::esp::radar_size,  60.f,  200.f, a, "%.0f");
            slider("Radar Range", &cfg::esp::radar_range, 30.f,  300.f, a, "%.0fm");
            slider("Radar Pos X", &cfg::esp::radar_x,     10.f,  400.f, a, "%.0f");
            slider("Radar Pos Y", &cfg::esp::radar_y,     10.f,  400.f, a, "%.0f");
        }
        separator(a);

        // ── Shadow ESP ───────────────────────────────────────
        checkbox("Shadow ESP", &cfg::esp::shadow_esp, a);
        if (cfg::esp::shadow_esp) {
            separator(a);
            slider("Shadow Offset", &cfg::esp::shadow_offset, 1.f, 12.f, a, "%.0f");
            slider("Shadow Alpha",  &cfg::esp::shadow_alpha,  0.05f, 0.6f, a, "%.2f");
        }
        separator(a);

        // ── Chams Body ────────────────────────────────────────
        checkbox("Chams Body", &cfg::esp::chams_body, a);
        if (cfg::esp::chams_body) {
            separator(a);
            colorpick("Body Color", &cfg::esp::chams_body_col,   a);
            slider("Body Alpha",    &cfg::esp::chams_body_alpha,  0.05f, 0.6f, a, "%.2f");
            checkbox("Body RGB",    &cfg::esp::chams_body_rgb,    a);
        }
        separator(a);

        // ── Hit Zone ──────────────────────────────────────────
        checkbox("Hit Zone", &cfg::esp::hit_zone, a);
        if (cfg::esp::hit_zone) {
            separator(a);
            colorpick("Head Color", &cfg::esp::hit_head_col,   a);
            colorpick("Body Color", &cfg::esp::hit_body_col,   a);
            slider("Zone Alpha",    &cfg::esp::hit_zone_alpha, 0.05f, 0.6f, a, "%.2f");
        }
        separator(a);

        // ── Footprints ────────────────────────────────────────
        checkbox("Footprints", &cfg::esp::footprints, a);
        if (cfg::esp::footprints) {
            separator(a);
            colorpick("Trail Color",  &cfg::esp::footprints_col,  a);
            slider("Trail Life",      &cfg::esp::footprints_life,  0.5f, 8.f, a, "%.1fs");
            slider("Trail Size",      &cfg::esp::footprints_size,  1.f,  8.f, a, "%.1f");
        }
        separator(a);

        // ── Chams Skeleton ────────────────────────────────────
        checkbox("Chams Skeleton", &cfg::esp::skel_chams, a);
        if (cfg::esp::skel_chams) {
            separator(a);
            spinner("Style", &cfg::esp::skel_style, {"Normal", "Neon", "Rainbow"}, a);
            slider("Thickness", &cfg::esp::skel_thick, 0.8f, 5.f, a, "%.1f");
            checkbox("HP Color",     &cfg::esp::skel_hp_color,   a);
            checkbox("Joints",       &cfg::esp::skel_joints,     a);
            checkbox("Dist Scale",   &cfg::esp::skel_dist_scale, a);
        }
        separator(a);

        slider("RGB speed", &cfg::rgb::speed, 0.1f, 5.f, a, "%.1f");
        separator(a);

        section("CROSSHAIR", a);
        checkbox("Crosshair", &cfg::crosshair::enabled, a);
        if (cfg::crosshair::enabled) {
            separator(a);
            spinner("CH type", &cfg::crosshair::type,
                  {"Dot","Cross","Circle","H-line","V-shape","Diamond","Star","T-shape"}, a);
            separator(a);
            slider("Size",  &cfg::crosshair::size,  2.f, 20.f, a, "%.1f");
            separator(a);
            slider("Thick", &cfg::crosshair::thick, 0.5f, 5.f,  a, "%.1f");
            separator(a);
            slider("Gap",   &cfg::crosshair::gap,   0.f, 10.f,  a, "%.1f");
            separator(a);
            checkbox("Outline",    &cfg::crosshair::outline, a);
            separator(a);
            checkbox("Spin",       &cfg::crosshair::spin,    a);
            if (cfg::crosshair::spin) {
                separator(a);
                slider("Spin speed", &cfg::crosshair::spin_speed, 0.1f, 5.f, a, "%.1f");
            }
            separator(a);
            colorpick("CH color",  &cfg::crosshair::color, a);
            checkbox("CH RGB",     &cfg::crosshair::rgb, a);
            separator(a);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  HOLY TAB — функции из holycheatlo
    // ─────────────────────────────────────────────────────────────────────────
    static void holy_tab(float a) {
        section("WEAPON", a);
        checkbox("Wallshot",  &cfg_holy::wallshot::enabled, a);
        if (cfg_holy::wallshot::enabled) {
            separator(a);
            static float ws_val = (float)cfg_holy::wallshot::value;
            slider("Wallshot power", &ws_val, 150.f, 2147000000.f, a, "%.0f");
            cfg_holy::wallshot::value = (int)ws_val;
        }
        separator(a);

        checkbox("Inf Ammo", &cfg_holy::inf_ammo::enabled, a);
        if (cfg_holy::inf_ammo::enabled) {
            separator(a);
            static float ammo_val = (float)cfg_holy::inf_ammo::value;
            slider("Ammo value", &ammo_val, 100.f, 30000.f, a, "%.0f");
            cfg_holy::inf_ammo::value = (int)ammo_val;
        }
        separator(a);

        section("PLAYER", a);
        checkbox("No Recoil", &cfg_holy::norecoil::enabled, a);
        if (cfg_holy::norecoil::enabled) {
            separator(a);
            slider("Recoil mult", &cfg_holy::norecoil::multiplier, 0.f, 1.f, a, "%.2f");
        }
        separator(a);

        checkbox("Invisible", &cfg_holy::test_h::invisible, a);
        separator(a);

        // ── MOVEMENT (из ковки) ──────────────────────────────────────
        section("MOVEMENT", a);
        checkbox("Air Jump",   &cfg_holy::air_jump::enabled,  a);
        separator(a);
        checkbox("Strafe",     &cfg_holy::strafe::enabled,    a);
        separator(a);
        checkbox("Bunny Hop",  &cfg_holy::bunny_hop::enabled, a);
        separator(a);

        // ── GRENADES (из ковки) ──────────────────────────────────────
        section("ANTI GRENADES", a);
        checkbox("Anti Flash",   &cfg_holy::anti_flash::enabled,   a);
        separator(a);
        checkbox("Anti Haze",    &cfg_holy::anti_smoke::enabled,    a);
        separator(a);
        checkbox("Anti Molotov", &cfg_holy::anti_molotov::enabled,  a);
        separator(a);

        // ── FOV (из ковки) ───────────────────────────────────────────
        section("FOV", a);
        checkbox("FOV Changer", &cfg_holy::fov_changer::enabled, a);
        if (cfg_holy::fov_changer::enabled) {
            separator(a);
            slider("FOV Value", &cfg_holy::fov_changer::value, 40.f, 90.f, a, "%.0f");
        }
        separator(a);
    }

    static void reset_font_cb() {
        cfg_font_scale = 1.0f;
        cfg_font_idx   = 0;
    }

    static void exit_cb() {
        exit(0);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  SETTINGS TAB — кастом меню
    // ─────────────────────────────────────────────────────────────────────────
    static void settings_tab(float a) {
        using namespace style;

        // ── Info ─────────────────────────────────────────────────────────────
        section("INFO", a);
        {
            ImGuiWindow* w  = ImGui::GetCurrentWindow();
            ImDrawList*  dl = w->DrawList;
            ImVec2 p   = w->DC.CursorPos;
            float  ww  = content_w > 0 ? content_w : ImGui::GetContentRegionAvail().x;
            float  pad = 8.f * S;
            float  h   = 24.f * S;
            float  gap = 4.f * S;
            constexpr float IR = 4.f;

            // Режим
            const char* mode_str = (mode_select::g_mode == 1)
                ? "Mode: RAGE" : "Mode: LEGIT";
            ImU32 mode_c = (mode_select::g_mode == 1)
                ? IM_COL32(220,60,60,(int)(220*a))
                : IM_COL32(60,200,100,(int)(220*a));
            dl->AddRectFilled(p, ImVec2(p.x+ww, p.y+h), col(clr::panel, a), IR);
            dl->AddRect(p, ImVec2(p.x+ww, p.y+h), col(clr::border, a), IR);
            ImGui::PushFont(fontMedium);
            dl->AddText(ImVec2(p.x+pad, p.y+(h-fontMedium->FontSize)*0.5f), mode_c, mode_str);
            ImGui::PopFont();
            ImGui::Dummy(ImVec2(0, h+gap));

            ImVec2 p2(p.x, p.y+h+gap);
            dl->AddRectFilled(p2, ImVec2(p2.x+ww, p2.y+h), col(clr::panel, a), IR);
            dl->AddRect(p2, ImVec2(p2.x+ww, p2.y+h), col(clr::border, a), IR);
            ImGui::PushFont(fontMedium);
            char buf[64];
            snprintf(buf, sizeof(buf), "Screen: %.0f x %.0f", g_sw, g_sh);
            dl->AddText(ImVec2(p2.x+pad, p2.y+(h-fontMedium->FontSize)*0.5f),
                col(clr::text, a), buf);
            ImGui::PopFont();
            ImGui::Dummy(ImVec2(0, h+gap));

            ImVec2 p3(p.x, p.y+h*2+gap*2);
            dl->AddRectFilled(p3, ImVec2(p3.x+ww, p3.y+h), col(clr::panel, a), IR);
            dl->AddRect(p3, ImVec2(p3.x+ww, p3.y+h), col(clr::border, a), IR);
            ImGui::PushFont(fontMedium);
            snprintf(buf, sizeof(buf), "FPS: %.0f", ImGui::GetIO().Framerate);
            dl->AddText(ImVec2(p3.x+pad, p3.y+(h-fontMedium->FontSize)*0.5f),
                col(clr::text, a), buf);
            ImGui::PopFont();
            ImGui::Dummy(ImVec2(0, h+gap));
        }
        separator(a);

        // ── Accent / RGB ──────────────────────────────────────────────────────
        section("ACCENT COLOR", a);
        colorpick("Accent", &cfg_accent_color, a);
        separator(a);
        checkbox("RGB Menu",  &cfg_rgb_menu,  a);
        if (cfg_rgb_menu) {
            separator(a);
            slider("RGB Speed", &cfg_rgb_speed, 0.1f, 5.f, a, "%.1f");
        }
        separator(a);

        // ── UI Shape ─────────────────────────────────────────────────────────
        section("UI SHAPE", a);
        checkbox("Corner Dots", &cfg_corner_dots, a);
        if (cfg_corner_dots) {
            separator(a);
            slider("Dot Size", &cfg_corner_dot_size, 1.f, 8.f, a, "%.1f");
        }
        separator(a);

        // ── Font ─────────────────────────────────────────────────────────────
        section("FONT", a);
        spinner("Font", &cfg_font_idx,
              {"Pixel Operator", "Comfortaa", "Comic Sans", "Minecraft"}, a);
        separator(a);
        slider("Font Scale", &cfg_font_scale, 0.7f, 1.5f, a, "%.2f");
        separator(a);
        button("Reset Font", a, reset_font_cb);
        separator(a);

        // ── Background Animation ──────────────────────────────────────────────
        section("BACKGROUND ANIMATION", a);
        spinner("Type",  &cfg_anim_type,  {"None", "Snow", "Rain", "Stars"}, a);
        if (cfg_anim_type > 0) {
            separator(a);
            slider("Speed", &cfg_anim_speed, 0.1f, 5.f, a, "%.1f");
            separator(a);
            slider("Count", &cfg_anim_count_f, 20.f, 200.f, a, "%.0f");
            cfg_anim_count = (int)cfg_anim_count_f;
        }
        separator(a);

        // ── Opacity ───────────────────────────────────────────────────────────
        section("MENU OPACITY", a);
        slider("Opacity", &cfg_menu_opacity, 0.4f, 1.0f, a, "%.2f");
        separator(a);

        // ── Window Size ───────────────────────────────────────────────────────
        section("WINDOW SIZE", a);
        {
            static float mw_cfg = mw;
            static float mh_cfg = mh;
            bool changed = false;
            changed |= slider("Width",  &mw_cfg, 700.f, 1200.f, a, "%.0f");
            separator(a);
            changed |= slider("Height", &mh_cfg, 450.f, 800.f,  a, "%.0f");
            if (changed) { mw = mw_cfg; mh = mh_cfg; }
        }
        separator(a);

        // ── Top Tab-bar Height ─────────────────────────────────────────────────
        section("TAB BAR HEIGHT", a);
        {
            static float hh_cfg = hh;
            if (slider("Header", &hh_cfg, 48.f, 96.f, a, "%.0f")) hh = hh_cfg;
        }
        separator(a);

        // ── Tab Animation ─────────────────────────────────────────────────────
        section("ANIMATION", a);
        slider("Tab Fade Speed", &cfg_tab_fade_speed, 4.f, 30.f, a, "%.1f");
        separator(a);
        slider("Open Speed", &cfg_open_speed, 2.f, 20.f, a, "%.1f");
        separator(a);

        // ── Border Style ──────────────────────────────────────────────────────
        section("BORDER STYLE", a);
        {
            static int border_style = 1;  // 0=None 1=Thin 2=Accent
            spinner("Border", &border_style, {"None", "Thin", "Accent"}, a);
            // Применяем к теме через clr::border
            if (border_style == 0) {
                clr::border = ImVec4(0,0,0,0);
            } else if (border_style == 1) {
                clr::border = ImVec4(28/255.f, 28/255.f, 28/255.f, 0.90f);
            } else {
                clr::border = ImVec4(
                    clr::accent.x * 0.6f,
                    clr::accent.y * 0.2f,
                    clr::accent.z * 0.2f, 0.85f);
            }
        }
        separator(a);

        // ── Inner Shine ───────────────────────────────────────────────────────
        section("INNER SHINE", a);
        checkbox("Inner Shine", &cfg_inner_shine, a);
        separator(a);

        // ── Window Rounding ───────────────────────────────────────────────────
        section("WINDOW ROUNDING", a);
        slider("Rounding", &cfg_win_rounding, 0.f, 20.f, a, "%.0f");
        separator(a);

        // ── Exit ─────────────────────────────────────────────────────────────
        separator(a);
        button("Exit", a, exit_cb);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  BG ANIMATIONS  (без None, +None = тип 0)
    // ─────────────────────────────────────────────────────────────────────────
    static void draw_bg_anim(float ma_val) {
        if (cfg_anim_type == 0) return;  // None
        ImDrawList* bg  = ImGui::GetBackgroundDrawList();
        ImGuiIO&    io2 = ImGui::GetIO();

        if (cfg_anim_type == 1) {  // Snow
            struct Flake { float x, y, spd, alpha, sz; };
            static Flake snow[200];
            static bool  si  = false;
            static int   lc  = 0;
            int cnt = cfg_anim_count;
            if (cnt > 200) cnt = 200;
            if (cnt < 10)  cnt = 10;
            if (!si || lc != cnt) {
                srand(12345u);
                for (int i = 0; i < cnt; i++) {
                    snow[i].x     = (float)(rand() % (int)(io2.DisplaySize.x + 1));
                    snow[i].y     = (float)(rand() % (int)(io2.DisplaySize.y + 1));
                    snow[i].spd   = 0.5f + (rand() % 100) / 100.f;
                    snow[i].alpha = 0.10f + (rand() % 35) / 100.f;
                    snow[i].sz    = 1.2f  + (rand() % 4);
                }
                si = true; lc = cnt;
            }
            for (int i = 0; i < cnt; i++) {
                snow[i].y += snow[i].spd * cfg_anim_speed;
                snow[i].x += sinf(snow[i].y * 0.018f) * 0.45f;
                if (snow[i].y > io2.DisplaySize.y + 4.f) {
                    snow[i].y = -4.f;
                    snow[i].x = (float)(rand() % (int)io2.DisplaySize.x);
                }
                bg->AddCircleFilled(ImVec2(snow[i].x, snow[i].y), snow[i].sz,
                    IM_COL32(200,190,255,(int)(snow[i].alpha*255)));
            }
        } else if (cfg_anim_type == 2) {  // Rain
            struct Drop { float x, y, spd, len, alpha; };
            static Drop rain[200];
            static bool ri = false;
            static int  rc = 0;
            int cnt = cfg_anim_count;
            if (cnt > 200) cnt = 200;
            if (cnt < 10)  cnt = 10;
            if (!ri || rc != cnt) {
                srand(54321u);
                for (int i = 0; i < cnt; i++) {
                    rain[i].x     = (float)(rand() % (int)(io2.DisplaySize.x + 1));
                    rain[i].y     = (float)(rand() % (int)(io2.DisplaySize.y + 1));
                    rain[i].spd   = 4.f  + (rand() % 80) / 10.f;
                    rain[i].len   = 8.f  + (rand() % 16);
                    rain[i].alpha = 0.12f + (rand() % 35) / 100.f;
                }
                ri = true; rc = cnt;
            }
            for (int i = 0; i < cnt; i++) {
                rain[i].y += rain[i].spd * cfg_anim_speed;
                if (rain[i].y > io2.DisplaySize.y + rain[i].len) {
                    rain[i].y = -rain[i].len;
                    rain[i].x = (float)(rand() % (int)io2.DisplaySize.x);
                }
                bg->AddLine(
                    ImVec2(rain[i].x, rain[i].y),
                    ImVec2(rain[i].x, rain[i].y + rain[i].len),
                    IM_COL32(
                        (int)(clr::accent.x*255*0.7f),
                        (int)(clr::accent.y*255*0.3f),
                        (int)(clr::accent.z*255*0.3f),
                        (int)(rain[i].alpha*255)),
                    1.f);
            }
        } else if (cfg_anim_type == 3) {  // Stars
            struct Star { float x, y, drift, phase, sz; };
            static Star  stars[200];
            static bool  sti = false;
            static int   stc = 0;
            int cnt = cfg_anim_count;
            if (cnt > 200) cnt = 200;
            if (cnt < 10)  cnt = 10;
            if (!sti || stc != cnt) {
                srand(99999u);
                for (int i = 0; i < cnt; i++) {
                    stars[i].x     = (float)(rand() % (int)(io2.DisplaySize.x + 1));
                    stars[i].y     = (float)(rand() % (int)(io2.DisplaySize.y + 1));
                    stars[i].drift = -0.12f + (rand() % 24) / 100.f;
                    stars[i].phase = (rand() % 628) / 100.f;
                    stars[i].sz    = 1.f + (rand() % 3);
                }
                sti = true; stc = cnt;
            }
            for (int i = 0; i < cnt; i++) {
                stars[i].phase += 0.022f * cfg_anim_speed;
                stars[i].x     += stars[i].drift * cfg_anim_speed;
                if (stars[i].x < -4.f)                     stars[i].x = io2.DisplaySize.x + 2.f;
                if (stars[i].x > io2.DisplaySize.x + 4.f)  stars[i].x = -2.f;
                float al = 0.25f + 0.40f * sinf(stars[i].phase);
                float hs = stars[i].sz + 1.f;
                ImU32 sc = IM_COL32(
                    (int)(clr::accent.x*255*0.9f + 40),
                    (int)(clr::accent.y*255*0.4f + 20),
                    (int)(clr::accent.z*255*0.4f + 20),
                    (int)(al*255));
                bg->AddLine(ImVec2(stars[i].x-hs, stars[i].y),
                            ImVec2(stars[i].x+hs, stars[i].y), sc, 1.f);
                bg->AddLine(ImVec2(stars[i].x, stars[i].y-hs),
                            ImVec2(stars[i].x, stars[i].y+hs), sc, 1.f);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  RENDER
    // ─────────────────────────────────────────────────────────────────────────
    void render() {
        // Сначала окно выбора режима
        if (!mode_select::g_done) {
            mode_select::render();
            return;
        }

        bar::render();

        using namespace style;
        g_font_idx   = cfg_font_idx;
        g_font_scale = cfg_font_scale;

        float dt = ImGui::GetIO().DeltaTime;
        ma = lrp(ma, bar::g_open ? 1.f : 0.f, ImClamp(12.f*dt, 0.f, 1.f));

        // Затемнение фона
        if (ma > 0.01f) {
            ImDrawList* bg = ImGui::GetBackgroundDrawList();
            int da = (int)(180 * ma * bar::game_alpha());
            bg->AddRectFilled(ImVec2(0,0), ImVec2(g_sw,g_sh), IM_COL32(0,0,0,da));
        }
        if (ma < 0.01f) return;

        // ── Accent update ────────────────────────────────────────────────────
        if (cfg_rgb_menu) {
            float _t = (float)ImGui::GetTime() * cfg_rgb_speed;
            ImVec4 rc = ImVec4(
                0.5f + 0.5f * sinf(_t),
                0.5f + 0.5f * sinf(_t + 2.094f),
                0.5f + 0.5f * sinf(_t + 4.189f),
                1.f);
            clr::accent       = ImVec4(rc.x, rc.y, rc.z, 0.92f);
            clr::accent_light = ImVec4(rc.x, rc.y, rc.z, 1.0f);
        } else {
            clr::accent       = ImVec4(cfg_accent_color.x, cfg_accent_color.y,
                                       cfg_accent_color.z, 0.92f);
            clr::accent_light = ImVec4(cfg_accent_color.x, cfg_accent_color.y,
                                       cfg_accent_color.z, 1.0f);
        }

        tick();

        if (tsw) {
            ta = lrp(ta, 0.f, ImClamp(18.f*dt, 0.f, 1.f));
            if (ta < 0.05f) { tab = ttab; tsw = false; scr_tgt = 0.f; scr_cur = 0.f; }
        } else {
            ta = lrp(ta, 1.f, ImClamp(14.f*dt, 0.f, 1.f));
        }

        float ca      = ma * ta;
        content_alpha = 1.f;

        // Фоновые анимации
        draw_bg_anim(ma);

        ImGui::PushStyleVar(ImGuiStyleVar_Alpha,            ma * cfg_menu_opacity);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,   0.f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,    ImVec2(0,0));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.f);
        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0,0,0,0));

        ImVec2 wsz(mw, mh);
        ImGui::SetNextWindowSize(wsz, ImGuiCond_Always);
        ImGui::SetNextWindowPos(
            ImVec2((g_sw-mw)*0.5f, (g_sh-mh)*0.5f), ImGuiCond_Once);

        ImGuiWindowFlags wf = ImGuiWindowFlags_NoTitleBar   |
                              ImGuiWindowFlags_NoResize      |
                              ImGuiWindowFlags_NoScrollbar   |
                              ImGuiWindowFlags_NoCollapse    |
                              ImGuiWindowFlags_NoMove;

        if (ImGui::Begin("##az", nullptr, wf)) {
            ImVec2      wp  = ImGui::GetWindowPos();
            touch::g_menu_x    = wp.x;
            touch::g_menu_y    = wp.y;
            touch::g_menu_w    = mw;
            touch::g_menu_h    = mh;
            touch::g_menu_open = true;
            ImDrawList* dl  = ImGui::GetWindowDrawList();
            ImGuiIO&    io  = ImGui::GetIO();
            ImVec2      mp  = io.MousePos;

            shadow(wp, wsz, ma);

            // ── Основной фон — строгий чёрный ─────────────────────────────
            constexpr float MR = 8.f;
            // Тёмный фон
            dl->AddRectFilled(wp, ImVec2(wp.x+wsz.x, wp.y+wsz.y),
                IM_COL32(8,8,8,250), MR);
            // Очень тонкий акцентный градиент сверху-слева
            {
                ImU32 c_tl = IM_COL32(
                    (int)(clr::accent.x*255*0.08f),
                    (int)(clr::accent.y*255*0.02f),
                    (int)(clr::accent.z*255*0.02f),
                    (int)(180*ma));
                ImU32 c_tr = IM_COL32(0,0,0,(int)(160*ma));
                ImU32 c_bl = IM_COL32(0,0,0,(int)(160*ma));
                ImU32 c_br = IM_COL32(0,0,0,(int)(140*ma));
                dl->AddRectFilledMultiColor(
                    wp, ImVec2(wp.x+wsz.x, wp.y+wsz.y),
                    c_tl, c_tr, c_br, c_bl);
            }
            // Внешняя рамка
            dl->AddRect(wp, ImVec2(wp.x+wsz.x, wp.y+wsz.y),
                IM_COL32(
                    (int)(clr::accent.x*255*0.35f),
                    (int)(clr::accent.y*255*0.1f),
                    (int)(clr::accent.z*255*0.1f),
                    (int)(200*ma)),
                MR, 0, 1.f);
            // Внутренняя highlight (белая, едва видна)
            dl->AddRect(
                ImVec2(wp.x+1, wp.y+1),
                ImVec2(wp.x+wsz.x-1, wp.y+wsz.y-1),
                IM_COL32(255,255,255,(int)(6*ma)),
                MR-1.f);

            // ── Top Bar (Header + горизонтальные вкладки) ─────────────────
            //
            //  Layout:
            //    [ ▌ AZENWIN ]   [ Aimbot ][ Visuals ][ Holy ][ Settings ]   [ RAGE ● ]
            //    └─ brand cell ─┘└── tab row (центрируется по высоте) ──────┘└ status ┘
            //
            //  Высота top-bar = hh (по умолчанию 62px). Активная вкладка
            //  подчёркивается тонкой акцентной линией снизу, без сильной
            //  заливки — современный flat-стиль.

            // Фон top-bar — чуть светлее основного полотна
            dl->AddRectFilled(
                ImVec2(wp.x + 1.f, wp.y + 1.f),
                ImVec2(wp.x + wsz.x - 1.f, wp.y + hh),
                IM_COL32(14, 14, 14, (int)(240 * ma)),
                MR - 1.f, ImDrawFlags_RoundCornersTop);

            // Разделительная линия под top-bar
            dl->AddLine(
                ImVec2(wp.x + 1.f,        wp.y + hh),
                ImVec2(wp.x + wsz.x - 1.f, wp.y + hh),
                IM_COL32(34, 34, 36, (int)(220 * ma)),
                1.f);

            // ── Brand cell (слева в top-bar) ──────────────────────────────
            //   ▌ AZENWIN
            float bx0 = wp.x + 14.f;
            float by0 = wp.y;
            float brand_strip_w = 3.f;
            float brand_gap     = 9.f;

            ImGui::PushFont(fontBold);
            const char* brand_txt = "AZENWIN";
            ImVec2 brand_tsz = ImGui::CalcTextSize(brand_txt);
            // Акцентная риска
            {
                float sy0 = by0 + (hh - brand_tsz.y) * 0.5f;
                float sy1 = sy0 + brand_tsz.y;
                dl->AddRectFilled(
                    ImVec2(bx0, sy0),
                    ImVec2(bx0 + brand_strip_w, sy1),
                    IM_COL32(
                        (int)(clr::accent.x * 255.f),
                        (int)(clr::accent.y * 255.f),
                        (int)(clr::accent.z * 255.f),
                        (int)(245 * ma)),
                    1.f);
            }
            // Бренд-текст
            {
                float tx_b = bx0 + brand_strip_w + brand_gap;
                float ty_b = by0 + (hh - brand_tsz.y) * 0.5f;
                // Тень
                dl->AddText(ImVec2(tx_b + 1.f, ty_b + 1.f),
                    IM_COL32(0, 0, 0, (int)(160 * ma)), brand_txt);
                // Основной
                dl->AddText(ImVec2(tx_b, ty_b),
                    IM_COL32(232, 232, 234, (int)(245 * ma)), brand_txt);
            }
            float brand_cell_w = brand_strip_w + brand_gap + brand_tsz.x + 14.f;
            ImGui::PopFont();

            // ── Status cell (справа в top-bar) ────────────────────────────
            //   RAGE/LEGIT + точка
            ImGui::PushFont(fontDesc);
            const char* mode_str = (mode_select::g_mode == 1) ? "RAGE" : "LEGIT";
            ImVec2 mode_tsz = ImGui::CalcTextSize(mode_str);
            float status_dot_r   = 3.f;
            float status_dot_gap = 8.f;
            float status_cell_w  = mode_tsz.x + status_dot_gap + status_dot_r * 2.f + 14.f;
            {
                float tx_s = wp.x + wsz.x - status_cell_w + 0.f;
                float ty_s = by0 + (hh - mode_tsz.y) * 0.5f;
                ImU32 mode_c = (mode_select::g_mode == 1)
                    ? IM_COL32(225, 60, 60, (int)(225 * ma))
                    : IM_COL32(60, 200, 95, (int)(225 * ma));
                dl->AddText(ImVec2(tx_s, ty_s), mode_c, mode_str);
                float dot_x = tx_s + mode_tsz.x + status_dot_gap + status_dot_r;
                float dot_y = ty_s + mode_tsz.y * 0.5f;
                dl->AddCircleFilled(ImVec2(dot_x, dot_y), status_dot_r, mode_c, 12);
                dl->AddCircleFilled(
                    ImVec2(dot_x, dot_y), status_dot_r + 3.f,
                    IM_COL32(
                        (int)(clr::accent.x * 255.f),
                        (int)(clr::accent.y * 255.f),
                        (int)(clr::accent.z * 255.f),
                        (int)(40 * ma)),
                    16);
            }
            ImGui::PopFont();

            // ── Tab row (центральная зона между brand и status) ───────────
            //   Кнопки-таблеты, активная подчёркнута акцентной линией.
            float tab_zone_x0 = wp.x + brand_cell_w + 10.f;
            float tab_zone_x1 = wp.x + wsz.x - status_cell_w - 10.f;
            float tab_zone_w  = tab_zone_x1 - tab_zone_x0;

            // Рассчитываем ширины вкладок по тексту
            ImGui::PushFont(fontMedium);
            float tab_text_h = fontMedium->FontSize;
            const float tab_pad_x = 18.f;
            const float tab_gap   = 6.f;
            float tab_widths[tc];
            float total_tabs_w = 0.f;
            for (int i = 0; i < tc; i++) {
                tab_widths[i] = ImGui::CalcTextSize(tabs[i]).x + tab_pad_x * 2.f;
                total_tabs_w += tab_widths[i];
            }
            total_tabs_w += tab_gap * (tc - 1);

            // Горизонтальный центрирующий offset; если не помещается — выравниваем по левому краю
            float tab_start_x;
            if (total_tabs_w <= tab_zone_w) {
                tab_start_x = tab_zone_x0 + (tab_zone_w - total_tabs_w) * 0.5f;
            } else {
                tab_start_x = tab_zone_x0;
            }
            float tab_h   = hh - 18.f;
            if (tab_h < 28.f) tab_h = 28.f;
            float tab_y   = by0 + (hh - tab_h) * 0.5f;

            constexpr float TR = 6.f;

            // Координаты вкладок для последующей проверки drag-исключения
            float tab_rects_x0[tc];
            float tab_rects_x1[tc];

            float cur_tx = tab_start_x;
            for (int i = 0; i < tc; i++) {
                float tw_i = tab_widths[i];
                ImVec2 tmin(cur_tx,         tab_y);
                ImVec2 tmax(cur_tx + tw_i,  tab_y + tab_h);

                tab_rects_x0[i] = tmin.x;
                tab_rects_x1[i] = tmax.x;

                bool sel = (tab == i);
                bool hov = ImGui::IsMouseHoveringRect(tmin, tmax);

                float sa = anim("t_"  + std::to_string(i), sel ? 1.f : 0.f, 14.f);
                float ha = anim("th_" + std::to_string(i), hov && !sel ? 1.f : 0.f, 14.f);

                // Hover-пилюля (только когда не выбран)
                if (ha > 0.01f) {
                    dl->AddRectFilled(tmin, tmax,
                        IM_COL32(26, 26, 28, (int)(190 * ha * ma)), TR);
                }

                // Активная вкладка: лёгкая заливка + акцентный underline
                if (sa > 0.01f) {
                    // Заливка
                    dl->AddRectFilled(tmin, tmax,
                        IM_COL32(22, 22, 24, (int)(220 * sa * ma)), TR);
                    // Тонкая рамка
                    dl->AddRect(tmin, tmax,
                        IM_COL32(46, 46, 50, (int)(200 * sa * ma)),
                        TR, 0, 1.f);
                    // Акцентный underline (внутри pill, у нижней кромки)
                    float un_h = 2.f;
                    float un_inset = 6.f;
                    dl->AddRectFilled(
                        ImVec2(tmin.x + un_inset, tmax.y - un_h - 3.f),
                        ImVec2(tmax.x - un_inset, tmax.y - 3.f),
                        IM_COL32(
                            (int)(clr::accent.x * 255.f),
                            (int)(clr::accent.y * 255.f),
                            (int)(clr::accent.z * 255.f),
                            (int)(235 * sa * ma)),
                        1.f);
                }

                // Подпись вкладки
                ImVec4 ttc = anim_col("tt_" + std::to_string(i),
                    sel ? clr::text_light : clr::text_dim, 14.f);
                ImVec2 tsz_lbl = ImGui::CalcTextSize(tabs[i]);
                float lx = cur_tx + (tw_i - tsz_lbl.x) * 0.5f;
                float ly = tab_y + (tab_h - tab_text_h) * 0.5f;
                // Лёгкая тень под текстом для контраста
                dl->AddText(ImVec2(lx + 1.f, ly + 1.f),
                    IM_COL32(0, 0, 0, (int)(120 * ma)), tabs[i]);
                dl->AddText(ImVec2(lx, ly), col(ttc, ma), tabs[i]);

                if (hov && ImGui::IsMouseClicked(0) && ma > 0.5f && !tsw) {
                    if (!popup() && tab != i) { ttab = i; tsw = true; }
                    close();
                }

                cur_tx += tw_i + tab_gap;
            }
            ImGui::PopFont();

            // ── Footer ────────────────────────────────────────────────────
            dl->AddLine(
                ImVec2(wp.x,         wp.y + wsz.y - fh),
                ImVec2(wp.x + wsz.x, wp.y + wsz.y - fh),
                IM_COL32(34, 34, 36, (int)(180 * ma)),
                1.f);

            ImGui::PushFont(fontDesc);
            {
                float footer_y = wp.y + wsz.y - fh + (fh - fontDesc->FontSize) * 0.5f;
                // Левая часть — название активной вкладки
                const char* active_lbl = (tab >= 0 && tab < tc) ? tabs[tab] : "";
                dl->AddText(
                    ImVec2(wp.x + 14.f, footer_y),
                    IM_COL32(140, 140, 144, (int)(200 * ma)),
                    active_lbl);
                // Правая часть — копирайт
                const char* cr_str = "@AzenWin";
                ImVec2 crsz = ImGui::CalcTextSize(cr_str);
                dl->AddText(
                    ImVec2(wp.x + wsz.x - crsz.x - 14.f, footer_y),
                    IM_COL32(70, 70, 72, (int)(180 * ma)),
                    cr_str);
            }
            ImGui::PopFont();

            // ── Content area (полная ширина окна, без sidebar) ───────────
            float csx    = wp.x + 1.f;
            float cex    = wp.x + wsz.x - 2.f;
            float cp_pad = 14.f;
            float sbw    = 12.f;
            float sbg    = 6.f;

            content_w = cex - csx - cp_pad * 2.f - sbg - sbw;

            float csy = wp.y + hh + 2.f + cp_pad;
            float ch  = (wp.y + wsz.y - fh) - csy - cp_pad;

            ImVec2 cpos(csx + cp_pad, csy);
            ImVec2 cmax_v(cpos.x + content_w, cpos.y + ch);

            ImGui::SetCursorScreenPos(cpos);
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha,       ca);
            ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0,0));
            ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0,0,0,0));
            ImGui::PushClipRect(cpos, cmax_v, true);

            content_alpha = ta;
            ImGui::BeginChild("##c", ImVec2(content_w, ch), false,
                ImGuiWindowFlags_NoScrollbar);

            float sm = ImGui::GetScrollMaxY();
            if (ImGui::IsMouseHoveringRect(cpos, cmax_v) && !popup()) {
                float wh = io.MouseWheel;
                if (wh != 0.f) scr_tgt -= wh * 60.f;
            }
            scr_tgt = ImClamp(scr_tgt, 0.f, ImMax(sm, 0.f));
            scr_cur = lrp(scr_cur, scr_tgt, ImClamp(16.f*dt, 0.f, 1.f));
            if (fabsf(scr_cur - scr_tgt) < 0.5f) scr_cur = scr_tgt;
            ImGui::SetScrollY(scr_cur);

            switch (tab) {
                case 0: aimbot_tab(ma);   break;
                case 1: visuals_tab(ma);  break;
                case 2: holy_tab(ma);     break;
                case 3: settings_tab(ma); break;
            }

            sm = ImGui::GetScrollMaxY();
            scr_tgt = ImClamp(scr_tgt, 0.f, ImMax(sm, 0.f));

            ImGui::EndChild();
            ImGui::PopClipRect();
            ImGui::PopStyleColor(1);
            ImGui::PopStyleVar(2);

            // ── Scrollbar ─────────────────────────────────────────────────
            float sbx = cmax_v.x + sbg;
            float sby = cpos.y;
            float sbh = ch;

            if (sm > 0.f) {
                constexpr float SBR = 2.f;
                dl->AddRectFilled(
                    ImVec2(sbx, sby), ImVec2(sbx + sbw, sby + sbh),
                    IM_COL32(16, 16, 16, (int)(200 * ma)), SBR);
                dl->AddRect(
                    ImVec2(sbx, sby), ImVec2(sbx + sbw, sby + sbh),
                    IM_COL32(30, 30, 30, (int)(160 * ma)), SBR, 0, 1.f);

                float sr = ch / (ch + sm);
                float gh = ImMax(sbh * sr, 30.f);
                float sn = scr_tgt / sm;
                float gy = sby + (sbh - gh) * sn;

                dl->AddRectFilled(
                    ImVec2(sbx + 2.f, gy + 2.f),
                    ImVec2(sbx + sbw - 2.f, gy + gh - 2.f),
                    IM_COL32(
                        (int)(clr::accent.x * 255.f),
                        (int)(clr::accent.y * 255.f),
                        (int)(clr::accent.z * 255.f),
                        (int)(210 * ma)),
                    SBR);

                ImRect sbr(
                    ImVec2(sbx - 18.f, sby),
                    ImVec2(sbx + sbw + 6.f, sby + sbh));
                bool sbhov = ImGui::IsMouseHoveringRect(sbr.Min, sbr.Max);
                static bool  sbd  = false;
                static float sbds = 0.f;
                if (sbhov && ImGui::IsMouseClicked(0) && !popup()) {
                    sbd  = true;
                    sbds = mp.y - gy;
                }
                if (!ImGui::IsMouseDown(0)) sbd = false;
                if (sbd && sm > 0.f) {
                    float nn = ((mp.y - sbds) - sby) / (sbh - gh);
                    nn = ImClamp(nn, 0.f, 1.f);
                    scr_tgt = nn * sm;
                    scr_cur = scr_tgt;
                }
            }

            // ── Drag (за top-bar, исключая зоны вкладок и status) ────────
            bool inm = (mp.x >= wp.x && mp.x <= wp.x + wsz.x &&
                        mp.y >= wp.y && mp.y <= wp.y + wsz.y);
            if (inm && !popup() && ImGui::IsMouseClicked(0)) {
                // Внутри полосы вкладок?
                bool ont = false;
                if (mp.y >= tab_y && mp.y <= tab_y + tab_h) {
                    for (int i = 0; i < tc; i++) {
                        if (mp.x >= tab_rects_x0[i] && mp.x <= tab_rects_x1[i]) {
                            ont = true;
                            break;
                        }
                    }
                }
                // Над content area?
                bool inca = (mp.x >= cpos.x   && mp.x <= cmax_v.x &&
                             mp.y >= cpos.y   && mp.y <= cmax_v.y);
                // Над scrollbar-расширенной зоной?
                bool insb = (mp.x >= sbx - 18.f && mp.x <= sbx + sbw + 6.f &&
                             mp.y >= sby         && mp.y <= sby + sbh);
                if (!ont && !inca && !insb) {
                    drag = true;
                    doff = ImVec2(mp.x - wp.x, mp.y - wp.y);
                }
            }
            if (drag) {
                if (ImGui::IsMouseDown(0)) {
                    ImVec2 np(mp.x - doff.x, mp.y - doff.y);
                    np.x = ImClamp(np.x, 0.f, g_sw - wsz.x);
                    np.y = ImClamp(np.y, 0.f, g_sh - wsz.y);
                    ImGui::SetWindowPos("##az", np);
                } else {
                    drag = false;
                }
            }
            if (popup()) drag = false;

            // ── Corner dots ───────────────────────────────────────────────
            if (cfg_corner_dots) {
                float cr = cfg_win_rounding;
                float ds = cfg_corner_dot_size;
                ImU32 dc = col(clr::accent, ma);
                dl->AddCircleFilled(ImVec2(wp.x+cr,        wp.y+cr       ), ds, dc);
                dl->AddCircleFilled(ImVec2(wp.x+wsz.x-cr,  wp.y+cr       ), ds, dc);
                dl->AddCircleFilled(ImVec2(wp.x+cr,        wp.y+wsz.y-cr ), ds, dc);
                dl->AddCircleFilled(ImVec2(wp.x+wsz.x-cr,  wp.y+wsz.y-cr ), ds, dc);
            }
        }
        touch::g_menu_open = false;
        ImGui::End();
        ImGui::PopStyleColor(1);
        ImGui::PopStyleVar(4);

        popups();

        if (ma > 0.5f) {
            esp_preview::render(ma);
        }
    }

} // namespace ui::menu
