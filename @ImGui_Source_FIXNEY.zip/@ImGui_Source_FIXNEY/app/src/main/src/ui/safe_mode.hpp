#pragma once

namespace ui {
namespace safe_mode {

    inline bool g_safe_mode = false;

} // namespace safe_mode
} // namespace ui
