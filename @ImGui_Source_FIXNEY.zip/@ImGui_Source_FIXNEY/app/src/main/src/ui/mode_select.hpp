#pragma once
// mode_select.hpp — окно выбора режима при запуске (Rage / Legit)
// Рендерится ОДИН РАЗ до появления основного меню.
// Никаких таймеров — только нажатие кнопки.

#include "imgui.h"
#include "imgui_internal.h"
#include "theme/theme.hpp"
#include <cstring>

namespace ui {
namespace mode_select {

    // Выбранный режим: 0=не выбран, 1=Rage, 2=Legit
    inline int  g_mode    = 0;
    inline bool g_done    = false;  // true — окно закрыто, показываем меню
    // Анимация появления
    static float s_alpha  = 0.f;
    // Анимация watermark fade-in после выбора
    static float s_wm_alpha = 0.f;
    static bool  s_wm_phase = false;  // true — показываем watermark перед меню
    static float s_wm_timer = 0.f;

    // Вызывается каждый кадр пока !g_done
    // Возвращает true когда пора переходить к меню
    inline bool render() {
        using namespace style;
        using namespace clr;

        ImGuiIO& io = ImGui::GetIO();
        float dt    = io.DeltaTime;

        // ── Фаза watermark (после выбора, до меню) ────────────────────────
        if (s_wm_phase) {
            s_wm_alpha += dt * 3.f;
            if (s_wm_alpha > 1.f) s_wm_alpha = 1.f;
            s_wm_timer += dt;

            // Рисуем watermark на весь экран
            ImDrawList* bg = ImGui::GetBackgroundDrawList();
            // Чёрный фон
            bg->AddRectFilled(ImVec2(0,0), io.DisplaySize,
                IM_COL32(0,0,0,(int)(220 * s_wm_alpha)));

            // Центр
            float cx = io.DisplaySize.x * 0.5f;
            float cy = io.DisplaySize.y * 0.5f;

            // Логотип @AzenWin
            ImGui::PushFont((fontBold != nullptr) ? fontBold : ImGui::GetFont());
            const char* wm_main = "@AzenWin";
            ImVec2 sz_main = ImGui::CalcTextSize(wm_main);
            // Тень
            bg->AddText(ImVec2(cx - sz_main.x*0.5f + 2, cy - sz_main.y - 2),
                IM_COL32(0,0,0,(int)(180*s_wm_alpha)), wm_main);
            // Текст с акцентом
            {
                ImU32 c_l = IM_COL32(255,255,255,(int)(255*s_wm_alpha));
                ImU32 c_r = IM_COL32(
                    (int)(accent.x*255),
                    (int)(accent.y*255),
                    (int)(accent.z*255),
                    (int)(255*s_wm_alpha));
                // Простой градиент по символам
                float px = cx - sz_main.x*0.5f;
                float py = cy - sz_main.y - 8.f;
                for (int i = 0; wm_main[i]; i++) {
                    float t = (float)i / (float)(sz_main.x > 0 ? 7 : 1);
                    if (t > 1.f) t = 1.f;
                    ImU32 cc = IM_COL32(
                        (int)(255*(1.f-t) + accent.x*255*t),
                        (int)(255*(1.f-t) + accent.y*255*t),
                        (int)(255*(1.f-t) + accent.z*255*t),
                        (int)(255*s_wm_alpha));
                    bg->AddText(ImVec2(px, py), cc, &wm_main[i], &wm_main[i+1]);
                    px += ImGui::CalcTextSize(&wm_main[i], &wm_main[i+1]).x;
                }
            }
            ImGui::PopFont();

            // Режим под именем
            ImGui::PushFont((fontDesc != nullptr) ? fontDesc : ImGui::GetFont());
            const char* mode_str = (g_mode == 1) ? "RAGE MODE" : "LEGIT MODE";
            ImVec2 sz_mode = ImGui::CalcTextSize(mode_str);
            ImU32 mode_col = (g_mode == 1)
                ? IM_COL32(220,30,30,(int)(220*s_wm_alpha))
                : IM_COL32(30,180,80,(int)(220*s_wm_alpha));
            bg->AddText(ImVec2(cx - sz_mode.x*0.5f, cy + 8.f), mode_col, mode_str);
            ImGui::PopFont();

            // После 1.5 сек — идём в меню
            if (s_wm_timer >= 1.5f) {
                g_done = true;
                return true;
            }
            return false;
        }

        // ── Анимация появления окна ───────────────────────────────────────
        s_alpha += dt * 6.f;
        if (s_alpha > 1.f) s_alpha = 1.f;

        // Затемняем фон
        ImDrawList* bg = ImGui::GetBackgroundDrawList();
        bg->AddRectFilled(ImVec2(0,0), io.DisplaySize,
            IM_COL32(0,0,0,(int)(200*s_alpha)));

        // Размеры окна выбора
        float ww = 1000.f;
        float wh = 1000.f;
        float wx = (io.DisplaySize.x - ww) * 0.5f;
        float wy = (io.DisplaySize.y - wh) * 0.5f;

        ImGui::SetNextWindowPos(ImVec2(wx, wy));
        ImGui::SetNextWindowSize(ImVec2(ww, wh));
        ImGui::SetNextWindowBgAlpha(0.f);

        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,    ImVec2(0,0));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.f);
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha,            s_alpha);

        ImGuiWindowFlags wf = ImGuiWindowFlags_NoTitleBar   |
                              ImGuiWindowFlags_NoResize      |
                              ImGuiWindowFlags_NoMove        |
                              ImGuiWindowFlags_NoScrollbar   |
                              ImGuiWindowFlags_NoCollapse;

        if (ImGui::Begin("##mode_sel", nullptr, wf)) {
            ImVec2 wp  = ImGui::GetWindowPos();
            ImDrawList* dl = ImGui::GetWindowDrawList();

            // Фон окна — чёрный с тонкой обводкой
            constexpr float R = 12.f;
            dl->AddRectFilled(wp, ImVec2(wp.x+ww, wp.y+wh),
                IM_COL32(10,10,10,245), R);
            dl->AddRect(wp, ImVec2(wp.x+ww, wp.y+wh),
                IM_COL32(
                    (int)(accent.x*255*0.7f),
                    (int)(accent.y*255*0.7f),
                    (int)(accent.z*255*0.7f),
                    200),
                R, 0, 1.5f);
            // Внутренний highlight
            dl->AddRect(
                ImVec2(wp.x+1, wp.y+1),
                ImVec2(wp.x+ww-1, wp.y+wh-1),
                IM_COL32(255,255,255,8), R-1.f);

            // Заголовок
            ImGui::PushFont((fontBold != nullptr) ? fontBold : ImGui::GetFont());
            const char* title = "@AzenWin";
            ImVec2 tsz = ImGui::CalcTextSize(title);
            float ty = wp.y + 28.f;
            float tx = wp.x + (ww - tsz.x) * 0.5f;
            // Тень
            dl->AddText(ImVec2(tx+1, ty+1), IM_COL32(0,0,0,160), title);
            dl->AddText(ImVec2(tx, ty), IM_COL32(
                (int)(accent_light.x*255),
                (int)(accent_light.y*255),
                (int)(accent_light.z*255),
                255), title);
            ImGui::PopFont();

            // Подзаголовок
            ImGui::PushFont((fontDesc != nullptr) ? fontDesc : ImGui::GetFont());
            const char* sub = "Select your mode";
            ImVec2 ssz = ImGui::CalcTextSize(sub);
            dl->AddText(
                ImVec2(wp.x + (ww-ssz.x)*0.5f, wp.y + 70.f),
                IM_COL32(140,140,140,200), sub);
            ImGui::PopFont();

            // Разделитель
            float lx1 = wp.x + 32.f;
            float lx2 = wp.x + ww - 32.f;
            float ly  = wp.y + 96.f;
            dl->AddLine(ImVec2(lx1,ly), ImVec2(lx2,ly),
                IM_COL32(
                    (int)(accent.x*255*0.4f),
                    (int)(accent.y*255*0.4f),
                    (int)(accent.z*255*0.4f),
                    160));

            // Кнопки RAGE / LEGIT
            float btn_w = 180.f;
            float btn_h = 64.f;
            float btn_y = wp.y + 116.f;
            float gap   = 20.f;
            float total = btn_w*2 + gap;
            float bx1   = wp.x + (ww - total) * 0.5f;
            float bx2   = bx1 + btn_w + gap;

            // ── RAGE кнопка ──────────────────────────────────────────────
            ImGui::SetCursorScreenPos(ImVec2(bx1, btn_y));
            bool rage_hov = ImGui::IsMouseHoveringRect(
                ImVec2(bx1, btn_y), ImVec2(bx1+btn_w, btn_y+btn_h));
            bool rage_click = rage_hov && ImGui::IsMouseClicked(0);

            // Фон RAGE — красный акцент
            ImU32 rage_bg = rage_hov
                ? IM_COL32(
                    (int)(accent_light.x*255),
                    (int)(accent_light.y*255),
                    (int)(accent_light.z*255),
                    220)
                : IM_COL32(
                    (int)(accent.x*255*0.3f),
                    (int)(accent.y*255*0.1f),
                    (int)(accent.z*255*0.1f),
                    200);
            dl->AddRectFilled(
                ImVec2(bx1, btn_y), ImVec2(bx1+btn_w, btn_y+btn_h),
                rage_bg, 8.f);
            dl->AddRect(
                ImVec2(bx1, btn_y), ImVec2(bx1+btn_w, btn_y+btn_h),
                IM_COL32(
                    (int)(accent.x*255),
                    (int)(accent.y*255),
                    (int)(accent.z*255),
                    180),
                8.f, 0, 1.2f);

            ImGui::PushFont((fontBold != nullptr) ? fontBold : ImGui::GetFont());
            const char* rage_label = "RAGE";
            ImVec2 rlsz = ImGui::CalcTextSize(rage_label);
            dl->AddText(
                ImVec2(bx1 + (btn_w-rlsz.x)*0.5f,
                       btn_y + (btn_h-rlsz.y)*0.5f - 6.f),
                IM_COL32(255,255,255,255), rage_label);
            ImGui::PopFont();

            ImGui::PushFont((fontDesc != nullptr) ? fontDesc : ImGui::GetFont());
            const char* rage_sub = "Max power";
            ImVec2 rssz = ImGui::CalcTextSize(rage_sub);
            dl->AddText(
                ImVec2(bx1 + (btn_w-rssz.x)*0.5f,
                       btn_y + (btn_h-rssz.y)*0.5f + 14.f),
                IM_COL32(200,180,180,200), rage_sub);
            ImGui::PopFont();

            if (rage_click) {
                g_mode     = 1;
                s_wm_phase = true;
                s_wm_alpha = 0.f;
                s_wm_timer = 0.f;
            }

            // ── LEGIT кнопка ─────────────────────────────────────────────
            bool legit_hov = ImGui::IsMouseHoveringRect(
                ImVec2(bx2, btn_y), ImVec2(bx2+btn_w, btn_y+btn_h));
            bool legit_click = legit_hov && ImGui::IsMouseClicked(0);

            ImU32 legit_bg = legit_hov
                ? IM_COL32(40,200,100,220)
                : IM_COL32(10,60,28,200);
            dl->AddRectFilled(
                ImVec2(bx2, btn_y), ImVec2(bx2+btn_w, btn_y+btn_h),
                legit_bg, 8.f);
            dl->AddRect(
                ImVec2(bx2, btn_y), ImVec2(bx2+btn_w, btn_y+btn_h),
                IM_COL32(30,180,80,180),
                8.f, 0, 1.2f);

            ImGui::PushFont((fontBold != nullptr) ? fontBold : ImGui::GetFont());
            const char* legit_label = "LEGIT";
            ImVec2 llsz = ImGui::CalcTextSize(legit_label);
            dl->AddText(
                ImVec2(bx2 + (btn_w-llsz.x)*0.5f,
                       btn_y + (btn_h-llsz.y)*0.5f - 6.f),
                IM_COL32(255,255,255,255), legit_label);
            ImGui::PopFont();

            ImGui::PushFont((fontDesc != nullptr) ? fontDesc : ImGui::GetFont());
            const char* legit_sub = "Undetectable";
            ImVec2 lssz = ImGui::CalcTextSize(legit_sub);
            dl->AddText(
                ImVec2(bx2 + (btn_w-lssz.x)*0.5f,
                       btn_y + (btn_h-lssz.y)*0.5f + 14.f),
                IM_COL32(180,240,200,200), legit_sub);
            ImGui::PopFont();

            if (legit_click) {
                g_mode     = 2;
                s_wm_phase = true;
                s_wm_alpha = 0.f;
                s_wm_timer = 0.f;
            }

            // Подсказка внизу
            ImGui::PushFont((fontDesc != nullptr) ? fontDesc : ImGui::GetFont());
            const char* hint = "Tap to select  •  @AzenWin";
            ImVec2 hsz = ImGui::CalcTextSize(hint);
            dl->AddText(
                ImVec2(wp.x + (ww-hsz.x)*0.5f, wp.y + wh - 32.f),
                IM_COL32(80,80,80,180), hint);
            ImGui::PopFont();
        }
        ImGui::End();
        ImGui::PopStyleVar(3);

        return false;
    }

} // namespace mode_select
} // namespace ui
