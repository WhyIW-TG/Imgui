#pragma once
// cfg_holy.hpp — конфиги для функций из holycheatlo
// отдельно от основного cfg.hpp чтобы не конфликтовать

namespace cfg_holy {

namespace wallshot {
    inline bool  enabled       = false;
    inline int   value         = 2147483646;
    inline int   restore_value = 150;
}

namespace inf_ammo {
    inline bool  enabled = false;
    inline int   value   = 10000;
}

namespace norecoil {
    inline bool  enabled    = false;
    inline float multiplier = 0.0f;
}

namespace test_h {
    inline bool  invisible = false;
}

// ─── НОВЫЕ ФИЧИ (перенесены из ковки) ───────────────────────────────────────

namespace air_jump {
    inline bool enabled = false;
}

namespace strafe {
    inline bool enabled = false;
}

namespace bunny_hop {
    inline bool enabled = false;
}

namespace anti_flash {
    inline bool enabled = false;
}

namespace anti_smoke {
    inline bool enabled = false;
}

namespace anti_molotov {
    inline bool enabled = false;
}

namespace fov_changer {
    inline bool  enabled = false;
    inline float value   = 60.f;  // 60 = fov4 из ковки
}

} // namespace cfg_holy
